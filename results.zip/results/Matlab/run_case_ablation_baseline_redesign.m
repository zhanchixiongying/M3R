function result = run_case_ablation_baseline_redesign(shared, cfg)
%RUN_CASE_ABLATION_BASELINE_REDESIGN
% New from-scratch experimental framework for reviewer-facing decomposition.
%
% Goals addressed explicitly:
%   1) True module-level ablation on the SAME Pcond front-end:
%      A0: Pcond -> average
%      A1: winsorize(Pcond) -> average
%      A2: winsorize(Pcond) -> neutral-trust FJ
%      A3: winsorize(Pcond) -> similarity-shrunk-trust FJ
%
%   2) Non-M0 competitor set:
%      B0: M0 published QPT baseline
%      B1: weighted average / linear opinion pool
%      B2: plain FJ (raw similarity trust, no winsor, no shrink)
%      B3: plain DeGroot (raw similarity trust)
%
%   3) Trust-near-uniform issue handled explicitly:
%      - report trust diagnostics
%      - report alpha sensitivity for shrinkage T(alpha)=alpha*Tsim+(1-alpha)*Tneutral
%      - interpret near-uniform trust as conservative shrinkage when expert rows are similar
%
% Usage:
%   result = run_case1_redesign_ablation_baselines();
%   result = run_case3_redesign_ablation_baselines();
%   package = run_revision_package();
%
% Notes:
%   - This is a new file. It does not patch any old runner.
%   - It reuses only the original case input 'shared' contract.

    validate_case_contract(shared);
    defaults = local_default_config(shared);
    if nargin < 2 || isempty(cfg)
        cfg = defaults;
    else
        cfg = merge_structs(defaults, cfg);
        cfg = adapt_cfg_to_case(shared, cfg);
    end
    rng(cfg.randomSeed, 'twister');

    signal = build_frontend_signal(shared, cfg);

    result = struct();
    result.caseID = shared.caseID;
    result.caseName = shared.caseName;
    result.shared = shared;
    result.cfg = cfg;
    result.signal = signal;

    % ---------------- main back-end comparison ----------------
    result.models = run_all_models(shared, cfg, signal);
    result.mainSummary = summarize_models(shared, result.models);
    result.ablationSummary = result.mainSummary(result.mainSummary.Family == "ablation", :);
    result.baselineSummary = result.mainSummary(ismember(result.mainSummary.Family, ["baseline","reference"]), :);

    % ---------------- trust diagnostics ----------------
    result.trustDiagnostics = build_trust_diagnostics(signal, cfg);
    result.alphaSensitivity = run_alpha_sensitivity(shared, cfg, signal, result.models.A3);
    result.parameterSensitivity = run_parameter_sensitivity(shared, cfg, signal, result.models.A3);
    result.specificationSensitivity = run_specification_sensitivity(shared, cfg, signal, result.models.A3);
    result.winsorAudit = build_winsor_audit(signal.Pcond, cfg.robust, shared);
    result.bridgeSensitivity = run_case3_bridge_sensitivity(shared, cfg, result.models.A3);

    % ---------------- optional fair robustness ----------------
    if cfg.robustness.enabled
        result.robustness = run_fair_robustness_suite(shared, cfg);
    else
        result.robustness = struct();
    end

    % ---------------- optional output ----------------
    if cfg.saveOutputs
        if ~exist(cfg.outputDir, 'dir')
            mkdir(cfg.outputDir);
        end
        prefix = lower(shared.caseID);
        save(fullfile(cfg.outputDir, [prefix '_redesign_result.mat']), 'result');
        writetable(result.mainSummary, fullfile(cfg.outputDir, [prefix '_redesign_main_summary.csv']));
        writetable(result.ablationSummary, fullfile(cfg.outputDir, [prefix '_redesign_ablation_summary.csv']));
        writetable(result.baselineSummary, fullfile(cfg.outputDir, [prefix '_redesign_baseline_summary.csv']));
        writetable(result.trustDiagnostics, fullfile(cfg.outputDir, [prefix '_redesign_trust_diagnostics.csv']));
        writetable(result.alphaSensitivity.table, fullfile(cfg.outputDir, [prefix '_redesign_alpha_sensitivity.csv']));
        writetable(result.parameterSensitivity.tau, fullfile(cfg.outputDir, [prefix '_redesign_tau_sensitivity.csv']));
        writetable(result.parameterSensitivity.lambda, fullfile(cfg.outputDir, [prefix '_redesign_lambda_sensitivity.csv']));
        writetable(result.specificationSensitivity.table, fullfile(cfg.outputDir, [prefix '_redesign_specification_sensitivity.csv']));
        writetable(result.winsorAudit, fullfile(cfg.outputDir, [prefix '_redesign_winsor_audit.csv']));
        if ~isempty(result.bridgeSensitivity)
            writetable(result.bridgeSensitivity, fullfile(cfg.outputDir, [prefix '_redesign_case3_bridge_sensitivity.csv']));
        end
        if cfg.robustness.enabled
            writetable(result.robustness.summary, fullfile(cfg.outputDir, [prefix '_redesign_robustness_summary.csv']));
            writetable(result.robustness.pairedVsM0, fullfile(cfg.outputDir, [prefix '_redesign_paired_vs_M0.csv']));
            writetable(result.robustness.rankingSummary, fullfile(cfg.outputDir, [prefix '_redesign_ranking_stability_summary.csv']));
            writetable(result.robustness.trialTable, fullfile(cfg.outputDir, [prefix '_redesign_robustness_trials.csv']));
        end
    end

    disp(' ');
    disp(['================ REDESIGNED ABLATION / BASELINE SUITE FOR ' shared.caseID ' ================']);
    disp('[MAIN SUMMARY]');
    disp(result.mainSummary);
    disp(' ');
    disp('[TRUST DIAGNOSTICS]');
    disp(result.trustDiagnostics);
    disp(' ');
    disp('[ALPHA SENSITIVITY]');
    disp(result.alphaSensitivity.table);
    disp(' ');
    disp('[TAU SENSITIVITY]');
    disp(result.parameterSensitivity.tau);
    disp(' ');
    disp('[LAMBDA SENSITIVITY]');
    disp(result.parameterSensitivity.lambda);
    disp(' ');
    disp('[SPECIFICATION SENSITIVITY]');
    disp(result.specificationSensitivity.table);
    if cfg.robustness.enabled
        disp(' ');
        disp('[ROBUSTNESS SUMMARY]');
        disp(result.robustness.summary);
        disp(' ');
        disp('[PAIRED VS M0]');
        disp(result.robustness.pairedVsM0);
    end
    disp('=========================================================================================');
end

function cfg = local_default_config(shared)
    cfg = struct();
    cfg.randomSeed = 20260409;
    cfg.saveOutputs = false;
    cfg.outputDir = fullfile(pwd, 'redesign_outputs');

    cfg.published = struct();
    cfg.published.cpt.alpha  = 0.88;
    cfg.published.cpt.beta   = 0.88;
    cfg.published.cpt.lambda = 2.25;
    cfg.published.cpt.gamma  = 0.61;
    cfg.published.cpt.delta  = 0.69;
    cfg.published.cpt.useAltWeighting = false;

    cfg.groupWeights = ones(shared.L,1) / shared.L;

    cfg.robust = struct();
    cfg.robust.mode = 'winsor';
    cfg.robust.winsorPct = 0.05;
    cfg.robust.quantileMethod = 'linear';
    cfg.robust.renormalize = true;
    cfg.robust.huberC = 1.5;
    cfg.robust.eps = 1e-12;

    cfg.consensus = struct();
    cfg.consensus.lambdaNeutral = 0.50 * ones(shared.L,1);
    cfg.consensus.maxIter = 500;
    cfg.consensus.tol = 1e-10;
    cfg.consensus.similarityEps = 1e-12;
    cfg.consensus.alphaShrink = 0.50;          % main conservative shrinkage setting
    cfg.consensus.alphaGrid = (0:0.1:1).';     % sensitivity over shrinkage intensity
    cfg.consensus.lambdaGrid = [0.30 0.50 0.70].';

    cfg.weightedAverage = struct();
    cfg.weightedAverage.scheme = 'similarity_centrality';
    cfg.weightedAverage.eps = 1e-12;

    cfg.robustness = struct();
    cfg.robustness.enabled = true;
    cfg.robustness.models = {'M0','A0','A1','A2','A3','B1','B2','B3'};
    cfg.robustness.repetitions = 100;
    cfg.robustness.weightLevels = [0.05 0.10 0.15];
    cfg.robustness.noiseLevels = [0.01 0.03 0.05];
    cfg.robustness.extremeLevels = [0.02 0.05 0.10];
    cfg.robustness.missingLevels = [0.05 0.10 0.15];

    cfg.parameterSensitivity = struct();
    cfg.parameterSensitivity.tauGrid = [0 0.01 0.03 0.05 0.10].';
    cfg.parameterSensitivity.lambdaGrid = [0.30 0.50 0.70].';

    cfg.specificationSensitivity = struct();
    cfg.specificationSensitivity.quantileMethods = {'linear','nearest','lower','higher'};
    cfg.specificationSensitivity.uniformShrinkWeight = 0.05;
end

function cfg = adapt_cfg_to_case(shared, cfg)
    if ~isfield(cfg, 'groupWeights') || numel(cfg.groupWeights) ~= shared.L
        cfg.groupWeights = ones(shared.L,1) / shared.L;
    else
        cfg.groupWeights = cfg.groupWeights(:);
        cfg.groupWeights = cfg.groupWeights / max(sum(cfg.groupWeights), 1e-12);
    end

    if ~isfield(cfg, 'consensus')
        cfg.consensus = struct();
    end
    if ~isfield(cfg.consensus, 'lambdaNeutral') || isempty(cfg.consensus.lambdaNeutral)
        cfg.consensus.lambdaNeutral = 0.50 * ones(shared.L,1);
    elseif isscalar(cfg.consensus.lambdaNeutral)
        cfg.consensus.lambdaNeutral = cfg.consensus.lambdaNeutral * ones(shared.L,1);
    else
        cfg.consensus.lambdaNeutral = cfg.consensus.lambdaNeutral(:);
        if numel(cfg.consensus.lambdaNeutral) ~= shared.L
            cfg.consensus.lambdaNeutral = 0.50 * ones(shared.L,1);
        end
    end
    if ~isfield(cfg.consensus, 'alphaGrid') || isempty(cfg.consensus.alphaGrid)
        cfg.consensus.alphaGrid = (0:0.1:1).';
    else
        cfg.consensus.alphaGrid = cfg.consensus.alphaGrid(:);
    end
end

function validate_case_contract(shared)
    must = {'X','L','m','n','experts','alternatives','criteria','costCriteria','costIdx','caseID','caseName'};
    for i = 1:numel(must)
        if ~isfield(shared, must{i})
            error('Missing shared.%s', must{i});
        end
    end
    if ~isequal(size(shared.X), [double(shared.L), double(shared.m), double(shared.n), 4])
        error('shared.X must have shape [L,m,n,4].');
    end
end

%% ============================= FRONT-END =================================
function signal = build_frontend_signal(shared, cfg)
    W = ldfdewm_weights(shared.X, shared.costIdx);
    AC = zeros(shared.L, shared.m);
    Pcond = zeros(shared.L, shared.m);
    for l = 1:shared.L
        El = reshape(shared.X(l,:,:,:), [shared.m, shared.n, 4]);
        [AC(l,:), Pcond(l,:)] = ldf_cpt_topsis_and_condprob(El, W(l,:), shared.costIdx, cfg.published.cpt);
    end
    signal = struct();
    signal.weights = W;
    signal.AC = AC;
    signal.Pcond = Pcond;
    signal.PcondWinsor = robustify_expert_signal_matrix(Pcond, cfg.robust);
    signal.Tneutral = build_neutral_trust(shared.L);
    signal.TsimRaw = build_trust_matrix_from_similarity(signal.Pcond, cfg.consensus.similarityEps);
    signal.TsimWinsor = build_trust_matrix_from_similarity(signal.PcondWinsor, cfg.consensus.similarityEps);
    signal.Tshrink = shrink_trust(signal.TsimWinsor, signal.Tneutral, cfg.consensus.alphaShrink, cfg.consensus.similarityEps);
    signal.lambdaNeutral = clamp_lambda(cfg.consensus.lambdaNeutral);
    signal.expertWeightsSimilarity = similarity_centrality_weights(signal.Pcond, cfg.weightedAverage.eps);
end

%% ============================= MODEL SUITE ===============================
function models = run_all_models(shared, cfg, signal)
    models = struct();

    % Reference / literature baseline
    models.M0 = model_M0_qpt(shared, cfg, signal.weights, signal.AC, signal.Pcond);

    % True ablation ladder requested by reviewer
    models.A0 = package_backend_result(shared, 'A0', 'ablation', 'Pcond -> average', ...
        aggregate_average(signal.Pcond), signal);
    models.A1 = package_backend_result(shared, 'A1', 'ablation', 'winsorize + average', ...
        aggregate_average(signal.PcondWinsor), signal);
    models.A2 = package_backend_result(shared, 'A2', 'ablation', 'winsorize + neutral-trust FJ', ...
        aggregate_fj(signal.PcondWinsor, signal.Tneutral, signal.lambdaNeutral, cfg.consensus.maxIter, cfg.consensus.tol), signal);
    models.A3 = package_backend_result(shared, 'A3', 'ablation', 'winsorize + similarity-shrunk-trust FJ', ...
        aggregate_fj(signal.PcondWinsor, signal.Tshrink, signal.lambdaNeutral, cfg.consensus.maxIter, cfg.consensus.tol), signal);

    % Additional ordinary aggregation competitors
    models.B1 = package_backend_result(shared, 'B1', 'baseline', 'similarity-centrality weighted average', ...
        aggregate_weighted_average(signal.Pcond, signal.expertWeightsSimilarity), signal);
    models.B2 = package_backend_result(shared, 'B2', 'baseline', 'plain FJ (raw similarity trust)', ...
        aggregate_fj(signal.Pcond, signal.TsimRaw, signal.lambdaNeutral, cfg.consensus.maxIter, cfg.consensus.tol), signal);
    models.B3 = package_backend_result(shared, 'B3', 'baseline', 'plain DeGroot (raw similarity trust)', ...
        aggregate_degroot(signal.Pcond, signal.TsimRaw, cfg.consensus.maxIter, cfg.consensus.tol), signal);
end

function out = model_M0_qpt(shared, cfg, W, AC, Pcond)
    [Pr, Praw, cosMat, xiMat] = qpt_aggregate(Pcond, cfg.groupWeights);
    [sortedScore, order] = sort(Pr(:), 'descend');
    out = struct();
    out.modelID = 'M0';
    out.family = 'reference';
    out.mode = 'published QPT';
    out.description = 'published QPT benchmark';
    out.weights = W;
    out.AC = AC;
    out.Pcond = Pcond;
    out.groupScore = Pr(:);
    out.Praw = Praw;
    out.cosMat = cosMat;
    out.xiMat = xiMat;
    out.order = order(:);
    out.finalRanking = shared.alternatives(order).';
    out.sortedScore = sortedScore(:);
    out.backend = struct('name', 'qpt');
end

function out = package_backend_result(shared, modelID, family, description, agg, signal)
    [sortedScore, order] = sort(agg.groupScore(:), 'descend');
    out = struct();
    out.modelID = modelID;
    out.family = family;
    out.mode = description;
    out.description = description;
    out.weights = signal.weights;
    out.AC = signal.AC;
    out.Pcond = signal.Pcond;
    out.groupScore = agg.groupScore(:);
    out.order = order(:);
    out.finalRanking = shared.alternatives(order).';
    out.sortedScore = sortedScore(:);
    out.backend = agg;
end

function agg = aggregate_average(S0)
    g = mean(S0, 1).';
    agg = struct();
    agg.name = 'average';
    agg.groupScore = normalize_score_vector(g);
    agg.alternativeLabels = (1:numel(g)).';
end

function agg = aggregate_weighted_average(S0, w)
    w = w(:) / sum(w(:));
    g = (w.' * S0).';
    agg = struct();
    agg.name = 'weighted_average';
    agg.groupScore = normalize_score_vector(g);
    agg.expertWeights = w;
    agg.alternativeLabels = (1:numel(g)).';
end

function agg = aggregate_fj(S0, T, lambda, maxIter, tol)
    fj = fj_consensus_safe(S0, T, lambda, maxIter, tol);
    g = mean(fj.Zeq, 1).';
    agg = struct();
    agg.name = 'fj';
    agg.groupScore = normalize_score_vector(g);
    agg.T = T;
    agg.lambda = lambda(:);
    agg.fj = fj;
    agg.alternativeLabels = (1:numel(g)).';
end

function agg = aggregate_degroot(S0, T, maxIter, tol)
    Z = S0;
    for t = 1:maxIter
        Znew = T * Z;
        if max(abs(Znew(:) - Z(:))) < tol
            Z = Znew;
            break;
        end
        Z = Znew;
    end
    g = mean(Z, 1).';
    agg = struct();
    agg.name = 'degroot';
    agg.groupScore = normalize_score_vector(g);
    agg.T = T;
    agg.Zeq = Z;
    agg.alternativeLabels = (1:numel(g)).';
end

function s = normalize_score_vector(s)
    s = s(:);
    s = max(s, 1e-12);
    s = s / sum(s);
end

%% ============================= SUMMARIES =================================
function T = summarize_models(shared, models)
    names = fieldnames(models);
    baseOrder = models.M0.order(:);
    baseTop1 = models.M0.finalRanking{1};

    n = numel(names);
    ModelID = strings(n,1);
    Family = strings(n,1);
    Mode = strings(n,1);
    Top1 = strings(n,1);
    Ranking = strings(n,1);
    HeadGap = zeros(n,1);
    NormHeadGap = zeros(n,1);
    SpearmanVsM0 = zeros(n,1);
    KendallVsM0 = zeros(n,1);
    Top1MatchM0 = false(n,1);
    PublishedTop1Match = false(n,1);
    TrustToNeutralFro = nan(n,1);
    TrustOffDiagStd = nan(n,1);

    pubTop = '';
    if isfield(shared, 'reference') && isfield(shared.reference, 'publishedRanking') && ~isempty(shared.reference.publishedRanking)
        pubTop = shared.reference.publishedRanking{1};
    end

    for i = 1:n
        r = models.(names{i});
        ModelID(i) = string(r.modelID);
        Family(i) = string(r.family);
        Mode(i) = string(r.mode);
        Top1(i) = string(r.finalRanking{1});
        Ranking(i) = string(strjoin(r.finalRanking(:).', ' > '));
        HeadGap(i) = head_gap(r.groupScore, r.order);
        NormHeadGap(i) = normalized_headgap(r.groupScore, r.order);
        [SpearmanVsM0(i), KendallVsM0(i)] = rank_correlation_from_orders(baseOrder, r.order(:));
        Top1MatchM0(i) = strcmp(r.finalRanking{1}, baseTop1);
        if ~isempty(pubTop)
            PublishedTop1Match(i) = strcmp(r.finalRanking{1}, pubTop);
        end

        if isfield(r, 'backend') && isfield(r.backend, 'T')
            tt = r.backend.T;
            tn = build_neutral_trust(size(tt,1));
            TrustToNeutralFro(i) = norm(tt - tn, 'fro');
            TrustOffDiagStd(i) = offdiag_std(tt);
        end
    end

    T = table(ModelID, Family, Mode, Top1, Ranking, HeadGap, NormHeadGap, SpearmanVsM0, KendallVsM0, Top1MatchM0, PublishedTop1Match, TrustToNeutralFro, TrustOffDiagStd);
end

function T = build_trust_diagnostics(signal, cfg)
    Name = ["neutral"; "similarity_raw"; "similarity_winsor"; "shrunk_similarity"];
    AlphaShrink = [0; 1; 1; cfg.consensus.alphaShrink];
    FroToNeutral = zeros(4,1);
    OffDiagStd = zeros(4,1);
    MeanRowEntropy = zeros(4,1);
    MaxRowProb = zeros(4,1);

    Ts = {signal.Tneutral, signal.TsimRaw, signal.TsimWinsor, signal.Tshrink};
    for i = 1:4
        T0 = Ts{i};
        FroToNeutral(i) = norm(T0 - signal.Tneutral, 'fro');
        OffDiagStd(i) = offdiag_std(T0);
        MeanRowEntropy(i) = mean(row_entropy(T0));
        MaxRowProb(i) = max(T0(:));
    end

    T = table(Name, AlphaShrink, FroToNeutral, OffDiagStd, MeanRowEntropy, MaxRowProb);
end

function out = run_alpha_sensitivity(shared, cfg, signal, baseA3)
    alphas = cfg.consensus.alphaGrid(:);
    n = numel(alphas);
    Alpha = zeros(n,1);
    Top1 = strings(n,1);
    Ranking = strings(n,1);
    HeadGap = zeros(n,1);
    NormHeadGap = zeros(n,1);
    SpearmanVsA3 = zeros(n,1);
    KendallVsA3 = zeros(n,1);
    FroToNeutral = zeros(n,1);
    OffDiagStd = zeros(n,1);
    MeanRowEntropy = zeros(n,1);

    for i = 1:n
        a = alphas(i);
        Tcur = shrink_trust(signal.TsimWinsor, signal.Tneutral, a, cfg.consensus.similarityEps);
        agg = aggregate_fj(signal.PcondWinsor, Tcur, signal.lambdaNeutral, cfg.consensus.maxIter, cfg.consensus.tol);
        [~, order] = sort(agg.groupScore(:), 'descend');
        altRank = shared.alternatives(order).';

        Alpha(i) = a;
        Top1(i) = string(altRank{1});
        Ranking(i) = string(strjoin(altRank(:).', ' > '));
        HeadGap(i) = head_gap(agg.groupScore, order);
        NormHeadGap(i) = normalized_headgap(agg.groupScore, order);
        [SpearmanVsA3(i), KendallVsA3(i)] = rank_correlation_from_orders(baseA3.order, order(:));
        FroToNeutral(i) = norm(Tcur - signal.Tneutral, 'fro');
        OffDiagStd(i) = offdiag_std(Tcur);
        MeanRowEntropy(i) = mean(row_entropy(Tcur));
    end

    out = struct();
    out.table = table(Alpha, Top1, Ranking, HeadGap, NormHeadGap, SpearmanVsA3, KendallVsA3, FroToNeutral, OffDiagStd, MeanRowEntropy);
end

function out = run_parameter_sensitivity(shared, cfg, signal, baseA3)
    tauGrid = cfg.parameterSensitivity.tauGrid(:);
    lambdaGrid = cfg.parameterSensitivity.lambdaGrid(:);

    out = struct();
    out.tau = build_tau_sensitivity_table(shared, cfg, signal.Pcond, baseA3, tauGrid);
    out.lambda = build_lambda_sensitivity_table(shared, cfg, signal.Pcond, baseA3, lambdaGrid);
end

function T = build_tau_sensitivity_table(shared, cfg, Pcond, baseA3, tauGrid)
    n = numel(tauGrid);
    Tau = zeros(n,1);
    Top1 = strings(n,1);
    Ranking = strings(n,1);
    HeadGap = zeros(n,1);
    NormHeadGap = zeros(n,1);
    SpearmanVsA3 = zeros(n,1);
    KendallVsA3 = zeros(n,1);
    ScoreL1VsA3 = zeros(n,1);
    ScoreL2VsA3 = zeros(n,1);
    TrustToNeutralFro = zeros(n,1);

    for i = 1:n
        robcfg = cfg.robust;
        robcfg.mode = 'winsor';
        robcfg.winsorPct = tauGrid(i);
        r = run_a3_variant(shared, cfg, Pcond, robcfg, cfg.consensus.lambdaNeutral, cfg.consensus.alphaShrink);
        Tau(i) = tauGrid(i);
        [Top1(i), Ranking(i), HeadGap(i), NormHeadGap(i), SpearmanVsA3(i), KendallVsA3(i), ...
            ScoreL1VsA3(i), ScoreL2VsA3(i), TrustToNeutralFro(i)] = collect_variant_metrics(shared, r, baseA3);
    end

    T = table(Tau, Top1, Ranking, HeadGap, NormHeadGap, SpearmanVsA3, KendallVsA3, ...
        ScoreL1VsA3, ScoreL2VsA3, TrustToNeutralFro);
end

function T = build_lambda_sensitivity_table(shared, cfg, Pcond, baseA3, lambdaGrid)
    n = numel(lambdaGrid);
    Lambda = zeros(n,1);
    Top1 = strings(n,1);
    Ranking = strings(n,1);
    HeadGap = zeros(n,1);
    NormHeadGap = zeros(n,1);
    SpearmanVsA3 = zeros(n,1);
    KendallVsA3 = zeros(n,1);
    ScoreL1VsA3 = zeros(n,1);
    ScoreL2VsA3 = zeros(n,1);
    TrustToNeutralFro = zeros(n,1);

    for i = 1:n
        lambda = lambdaGrid(i) * ones(shared.L,1);
        r = run_a3_variant(shared, cfg, Pcond, cfg.robust, lambda, cfg.consensus.alphaShrink);
        Lambda(i) = lambdaGrid(i);
        [Top1(i), Ranking(i), HeadGap(i), NormHeadGap(i), SpearmanVsA3(i), KendallVsA3(i), ...
            ScoreL1VsA3(i), ScoreL2VsA3(i), TrustToNeutralFro(i)] = collect_variant_metrics(shared, r, baseA3);
    end

    T = table(Lambda, Top1, Ranking, HeadGap, NormHeadGap, SpearmanVsA3, KendallVsA3, ...
        ScoreL1VsA3, ScoreL2VsA3, TrustToNeutralFro);
end

function out = run_specification_sensitivity(shared, cfg, signal, baseA3)
    variants = {};
    qMethods = cfg.specificationSensitivity.quantileMethods;
    for i = 1:numel(qMethods)
        robcfg = cfg.robust;
        robcfg.mode = 'winsor';
        robcfg.quantileMethod = qMethods{i};
        robcfg.renormalize = true;
        variants(end+1,:) = {['winsor_' qMethods{i}], robcfg}; %#ok<AGROW>
    end

    robcfg = cfg.robust;
    robcfg.mode = 'none';
    variants(end+1,:) = {'no_winsorization', robcfg};

    robcfg = cfg.robust;
    robcfg.mode = 'winsor';
    robcfg.renormalize = false;
    variants(end+1,:) = {'winsor_without_renormalization', robcfg};

    robcfg = cfg.robust;
    robcfg.mode = 'huber';
    variants(end+1,:) = {'huber_regularization', robcfg};

    robcfg = cfg.robust;
    robcfg.mode = 'epsilon_floor';
    variants(end+1,:) = {'epsilon_floor_only', robcfg};

    robcfg = cfg.robust;
    robcfg.mode = 'uniform_shrink';
    robcfg.uniformShrinkWeight = cfg.specificationSensitivity.uniformShrinkWeight;
    variants(end+1,:) = {'uniform_shrinkage', robcfg};

    n = size(variants,1);
    Variant = strings(n,1);
    RobustMode = strings(n,1);
    QuantileMethod = strings(n,1);
    WinsorPct = zeros(n,1);
    Renormalize = false(n,1);
    Top1 = strings(n,1);
    Ranking = strings(n,1);
    HeadGap = zeros(n,1);
    NormHeadGap = zeros(n,1);
    SpearmanVsA3 = zeros(n,1);
    KendallVsA3 = zeros(n,1);
    ScoreL1VsA3 = zeros(n,1);
    ScoreL2VsA3 = zeros(n,1);
    TrustToNeutralFro = zeros(n,1);

    for i = 1:n
        Variant(i) = string(variants{i,1});
        robcfg = variants{i,2};
        RobustMode(i) = string(robcfg.mode);
        QuantileMethod(i) = string(get_struct_field(robcfg, 'quantileMethod', ''));
        WinsorPct(i) = get_struct_field(robcfg, 'winsorPct', NaN);
        Renormalize(i) = logical(get_struct_field(robcfg, 'renormalize', true));
        r = run_a3_variant(shared, cfg, signal.Pcond, robcfg, cfg.consensus.lambdaNeutral, cfg.consensus.alphaShrink);
        [Top1(i), Ranking(i), HeadGap(i), NormHeadGap(i), SpearmanVsA3(i), KendallVsA3(i), ...
            ScoreL1VsA3(i), ScoreL2VsA3(i), TrustToNeutralFro(i)] = collect_variant_metrics(shared, r, baseA3);
    end

    out = struct();
    out.table = table(Variant, RobustMode, QuantileMethod, WinsorPct, Renormalize, Top1, Ranking, ...
        HeadGap, NormHeadGap, SpearmanVsA3, KendallVsA3, ScoreL1VsA3, ScoreL2VsA3, TrustToNeutralFro);
end

function audit = build_winsor_audit(Pcond, robcfg, shared)
    n = size(Pcond,1);
    CaseID = strings(n,1);
    Expert = strings(n,1);
    WinsorPct = zeros(n,1);
    QuantileMethod = strings(n,1);
    OriginalRow = strings(n,1);
    LowerQuantile = zeros(n,1);
    UpperQuantile = zeros(n,1);
    AfterClip = strings(n,1);
    AfterRenorm = strings(n,1);
    MaxAbsChange = zeros(n,1);

    method = get_struct_field(robcfg, 'quantileMethod', 'linear');
    for l = 1:n
        row = Pcond(l,:);
        lo = local_quantile(row, robcfg.winsorPct, method);
        hi = local_quantile(row, 1-robcfg.winsorPct, method);
        clipped = min(max(row, lo), hi);
        renorm = max(clipped, robcfg.eps);
        renorm = renorm / sum(renorm);

        CaseID(l) = string(shared.caseID);
        Expert(l) = string(shared.experts{l});
        WinsorPct(l) = robcfg.winsorPct;
        QuantileMethod(l) = string(method);
        OriginalRow(l) = string(format_numeric_row(row));
        LowerQuantile(l) = lo;
        UpperQuantile(l) = hi;
        AfterClip(l) = string(format_numeric_row(clipped));
        AfterRenorm(l) = string(format_numeric_row(renorm));
        MaxAbsChange(l) = max(abs(renorm(:) - row(:)));
    end

    audit = table(CaseID, Expert, WinsorPct, QuantileMethod, OriginalRow, LowerQuantile, ...
        UpperQuantile, AfterClip, AfterRenorm, MaxAbsChange);
end

function T = run_case3_bridge_sensitivity(shared, cfg, baseA3)
    if ~isfield(shared, 'rawIVFF') || isempty(shared.rawIVFF)
        T = table();
        return;
    end

    rules = {'midpoint_slack_50_50','midpoint_slack_70_30','midpoint_slack_30_70', ...
        'fixed_ab_50_50','interval_width_only'};
    BridgeRule = strings(0,1);
    ModelID = strings(0,1);
    Top1 = strings(0,1);
    Ranking = strings(0,1);
    HeadGap = zeros(0,1);
    NormHeadGap = zeros(0,1);
    SpearmanVsDefaultA3 = zeros(0,1);
    KendallVsDefaultA3 = zeros(0,1);
    ScoreL1VsDefaultA3 = zeros(0,1);
    ScoreL2VsDefaultA3 = zeros(0,1);

    for rix = 1:numel(rules)
        shared2 = shared;
        shared2.X = bridge_ivff_tensor(shared.rawIVFF, rules{rix});
        shared2.bridgeRuleName = rules{rix};
        signal2 = build_frontend_signal(shared2, cfg);
        models2 = run_all_models(shared2, cfg, signal2);
        ids = {'M0','A3'};
        for j = 1:numel(ids)
            rr = models2.(ids{j});
            BridgeRule(end+1,1) = string(rules{rix}); %#ok<AGROW>
            ModelID(end+1,1) = string(ids{j}); %#ok<AGROW>
            Top1(end+1,1) = string(rr.finalRanking{1}); %#ok<AGROW>
            Ranking(end+1,1) = string(strjoin(rr.finalRanking(:).', ' > ')); %#ok<AGROW>
            HeadGap(end+1,1) = head_gap(rr.groupScore, rr.order); %#ok<AGROW>
            NormHeadGap(end+1,1) = normalized_headgap(rr.groupScore, rr.order); %#ok<AGROW>
            [rho, ktau] = rank_correlation_from_orders(baseA3.order, rr.order(:));
            SpearmanVsDefaultA3(end+1,1) = rho; %#ok<AGROW>
            KendallVsDefaultA3(end+1,1) = ktau; %#ok<AGROW>
            ScoreL1VsDefaultA3(end+1,1) = sum(abs(rr.groupScore(:) - baseA3.groupScore(:))); %#ok<AGROW>
            ScoreL2VsDefaultA3(end+1,1) = norm(rr.groupScore(:) - baseA3.groupScore(:)); %#ok<AGROW>
        end
    end

    T = table(BridgeRule, ModelID, Top1, Ranking, HeadGap, NormHeadGap, ...
        SpearmanVsDefaultA3, KendallVsDefaultA3, ScoreL1VsDefaultA3, ScoreL2VsDefaultA3);
end

function r = run_a3_variant(shared, cfg, Pcond, robcfg, lambda, alpha)
    Srob = robustify_expert_signal_matrix(Pcond, robcfg);
    Tneutral = build_neutral_trust(shared.L);
    Tsim = build_trust_matrix_from_similarity(Srob, cfg.consensus.similarityEps);
    Tshrink = shrink_trust(Tsim, Tneutral, alpha, cfg.consensus.similarityEps);
    agg = aggregate_fj(Srob, Tshrink, clamp_lambda(lambda), cfg.consensus.maxIter, cfg.consensus.tol);
    [sortedScore, order] = sort(agg.groupScore(:), 'descend');
    r = struct();
    r.groupScore = agg.groupScore(:);
    r.order = order(:);
    r.finalRanking = shared.alternatives(order).';
    r.sortedScore = sortedScore(:);
    r.T = Tshrink;
end

function [Top1, Ranking, HeadGap, NormHeadGap, SpearmanVsBase, KendallVsBase, ScoreL1, ScoreL2, TrustToNeutralFro] = collect_variant_metrics(shared, r, base)
    Top1 = string(r.finalRanking{1});
    Ranking = string(strjoin(r.finalRanking(:).', ' > '));
    HeadGap = head_gap(r.groupScore, r.order);
    NormHeadGap = normalized_headgap(r.groupScore, r.order);
    [SpearmanVsBase, KendallVsBase] = rank_correlation_from_orders(base.order, r.order(:));
    ScoreL1 = sum(abs(r.groupScore(:) - base.groupScore(:)));
    ScoreL2 = norm(r.groupScore(:) - base.groupScore(:));
    TrustToNeutralFro = norm(r.T - build_neutral_trust(shared.L), 'fro');
end

function X = bridge_ivff_tensor(rawIVFF, rule)
    [L,m,n,~] = size(rawIVFF);
    X = zeros(L,m,n,4);
    for l = 1:L
        for i = 1:m
            for j = 1:n
                ivff = reshape(rawIVFF(l,i,j,:), [1,4]);
                X(l,i,j,:) = reshape(bridge_ivff_entry(ivff, rule), [1,1,1,4]);
            end
        end
    end
end

function e = bridge_ivff_entry(ivff, rule)
    zlb = ivff(1); zub = ivff(2);
    elb = ivff(3); eub = ivff(4);
    A = (zlb + zub) / 2;
    U = (elb + eub) / 2;
    intervalUnc = ((zub - zlb) + (eub - elb)) / 2;
    fermateanSlack = max(0, 1 - A^3 - U^3);

    switch lower(rule)
        case 'midpoint_slack_50_50'
            unc = min(1, 0.5*intervalUnc + 0.5*fermateanSlack);
            a = 1 - unc; b = unc;
        case 'midpoint_slack_70_30'
            unc = min(1, 0.7*intervalUnc + 0.3*fermateanSlack);
            a = 1 - unc; b = unc;
        case 'midpoint_slack_30_70'
            unc = min(1, 0.3*intervalUnc + 0.7*fermateanSlack);
            a = 1 - unc; b = unc;
        case 'fixed_ab_50_50'
            a = 0.5; b = 0.5;
        case 'interval_width_only'
            unc = min(1, intervalUnc);
            a = 1 - unc; b = unc;
        otherwise
            error('Unknown CASE3 bridge rule: %s', rule);
    end
    e = sanitize_ldf_entry([A,U,a,b]);
end

%% ============================= ROBUSTNESS ================================
function out = run_fair_robustness_suite(shared, cfg)
    baseSignal = build_frontend_signal(shared, cfg);
    baseModels = run_all_models(shared, cfg, baseSignal);

    specs = {
        'weight_perturb', cfg.robustness.weightLevels, @(lvl) perturb_weight_only(baseSignal.weights, lvl), true;
        'input_noise',    cfg.robustness.noiseLevels,  @(lvl) perturb_input_noise(shared, lvl), false;
        'extreme_value',  cfg.robustness.extremeLevels,@(lvl) perturb_extreme_value(shared, lvl), false;
        'missing_fill',   cfg.robustness.missingLevels,@(lvl) perturb_missing_fill(shared, lvl), false};

    rows = cell(0,1);
    for s = 1:size(specs,1)
        fam = specs{s,1};
        levels = specs{s,2};
        makePert = specs{s,3};
        isWeightOnly = specs{s,4};
        for ii = 1:numel(levels)
            level = levels(ii);
            for r = 1:cfg.robustness.repetitions
                trialSeed = cfg.randomSeed + 100000*s + 10000*ii + r;
                rng(trialSeed, 'twister');
                pert = makePert(level);
                if isWeightOnly
                    sharedPert = shared;
                    signalPert = build_frontend_signal_with_weight_override(sharedPert, cfg, pert.W);
                else
                    sharedPert = pert.shared;
                    signalPert = build_frontend_signal(sharedPert, cfg);
                end
                modelPert = run_all_models(sharedPert, cfg, signalPert);
                rows{end+1,1} = collect_robustness_rows(shared, fam, level, r, trialSeed, baseModels, modelPert, cfg.robustness.models); %#ok<AGROW>
            end
        end
    end

    trialTable = vertcat(rows{:});
    summary = summarize_robustness_trials(trialTable);
    pairedVsM0 = summarize_paired_vs_reference(trialTable, 'M0', 'A3');
    rankingSummary = summarize_ranking_stability(trialTable);

    out = struct();
    out.trialTable = trialTable;
    out.summary = summary;
    out.pairedVsM0 = pairedVsM0;
    out.rankingSummary = rankingSummary;
end

function T = collect_robustness_rows(shared, fam, level, rep, trialSeed, baseModels, modelPert, keepIDs)
    CaseID = strings(0,1);
    PerturbationFamily = strings(0,1);
    ModelID = strings(0,1);
    Level = zeros(0,1);
    Rep = zeros(0,1);
    TrialSeed = zeros(0,1);
    Top1 = strings(0,1);
    Ranking = strings(0,1);
    HeadGapBase = zeros(0,1);
    HeadGap = zeros(0,1);
    Abs_dHG = zeros(0,1);
    NormHeadGapBase = zeros(0,1);
    NormHeadGap = zeros(0,1);
    Abs_dNHG = zeros(0,1);
    SpearmanVsBase = zeros(0,1);
    KendallVsBase = zeros(0,1);
    Top1KeepBase = false(0,1);
    ExactRankKeepBase = false(0,1);
    Top2SetKeepBase = false(0,1);
    PairwiseReversalRate = zeros(0,1);
    ScoreL1Distance = zeros(0,1);
    ScoreL2Distance = zeros(0,1);
    DecisionRegret = zeros(0,1);

    for i = 1:numel(keepIDs)
        id = keepIDs{i};
        b = baseModels.(id);
        p = modelPert.(id);
        CaseID(end+1,1) = string(shared.caseID);
        PerturbationFamily(end+1,1) = string(fam);
        ModelID(end+1,1) = string(id);
        Level(end+1,1) = level;
        Rep(end+1,1) = rep;
        TrialSeed(end+1,1) = trialSeed;
        Top1(end+1,1) = string(p.finalRanking{1});
        Ranking(end+1,1) = string(strjoin(p.finalRanking(:).', ' > '));
        HeadGapBase(end+1,1) = head_gap(b.groupScore, b.order);
        HeadGap(end+1,1) = head_gap(p.groupScore, p.order);
        Abs_dHG(end+1,1) = abs(HeadGap(end) - HeadGapBase(end));
        NormHeadGapBase(end+1,1) = normalized_headgap(b.groupScore, b.order);
        NormHeadGap(end+1,1) = normalized_headgap(p.groupScore, p.order);
        Abs_dNHG(end+1,1) = abs(NormHeadGap(end) - NormHeadGapBase(end));
        [SpearmanVsBase(end+1,1), KendallVsBase(end+1,1)] = rank_correlation_from_orders(b.order, p.order);
        Top1KeepBase(end+1,1) = strcmp(b.finalRanking{1}, p.finalRanking{1});
        ExactRankKeepBase(end+1,1) = isequal(b.order(:), p.order(:));
        Top2SetKeepBase(end+1,1) = topk_set_keep(b.order, p.order, min(2, shared.m));
        PairwiseReversalRate(end+1,1) = pairwise_reversal_rate(b.order, p.order);
        ScoreL1Distance(end+1,1) = sum(abs(p.groupScore(:) - b.groupScore(:)));
        ScoreL2Distance(end+1,1) = norm(p.groupScore(:) - b.groupScore(:));
        DecisionRegret(end+1,1) = max(p.groupScore(:)) - p.groupScore(b.order(1));
    end

    T = table(CaseID, PerturbationFamily, ModelID, Level, Rep, TrialSeed, Top1, Ranking, ...
        HeadGapBase, HeadGap, Abs_dHG, NormHeadGapBase, NormHeadGap, Abs_dNHG, ...
        SpearmanVsBase, KendallVsBase, Top1KeepBase, ExactRankKeepBase, Top2SetKeepBase, ...
        PairwiseReversalRate, ScoreL1Distance, ScoreL2Distance, DecisionRegret);
end

function signal = build_frontend_signal_with_weight_override(shared, cfg, W)
    W = validate_weight_override(W, shared);
    AC = zeros(shared.L, shared.m);
    Pcond = zeros(shared.L, shared.m);
    for l = 1:shared.L
        El = reshape(shared.X(l,:,:,:), [shared.m, shared.n, 4]);
        [AC(l,:), Pcond(l,:)] = ldf_cpt_topsis_and_condprob(El, W(l,:), shared.costIdx, cfg.published.cpt);
    end
    signal = struct();
    signal.weights = W;
    signal.AC = AC;
    signal.Pcond = Pcond;
    signal.PcondWinsor = robustify_expert_signal_matrix(Pcond, cfg.robust);
    signal.Tneutral = build_neutral_trust(shared.L);
    signal.TsimRaw = build_trust_matrix_from_similarity(signal.Pcond, cfg.consensus.similarityEps);
    signal.TsimWinsor = build_trust_matrix_from_similarity(signal.PcondWinsor, cfg.consensus.similarityEps);
    signal.Tshrink = shrink_trust(signal.TsimWinsor, signal.Tneutral, cfg.consensus.alphaShrink, cfg.consensus.similarityEps);
    signal.lambdaNeutral = clamp_lambda(cfg.consensus.lambdaNeutral);
    signal.expertWeightsSimilarity = similarity_centrality_weights(signal.Pcond, cfg.weightedAverage.eps);
end

function pert = perturb_weight_only(baseW, level)
    G = 1 + level * randn(size(baseW));
    W = max(baseW .* G, 1e-12);
    W = W ./ sum(W,2);
    pert = struct('W', W);
end

function pert = perturb_input_noise(shared, level)
    Xp = shared.X + level * randn(size(shared.X));
    Xp = sanitize_ldf_tensor(Xp);
    pert = struct('shared', replace_X(shared, Xp));
end

function pert = perturb_extreme_value(shared, level)
    Xp = shared.X;
    [L,m,n,~] = size(Xp);
    total = L*m*n;
    k = max(1, round(level * total));
    idx = randperm(total, k);
    for t = 1:numel(idx)
        [l,i,j] = ind2sub([L,m,n], idx(t));
        e = reshape(Xp(l,i,j,:), [1,4]);
        e = double(e >= 0.5);
        Xp(l,i,j,:) = reshape(sanitize_ldf_entry(e), [1,1,1,4]);
    end
    pert = struct('shared', replace_X(shared, Xp));
end

function pert = perturb_missing_fill(shared, level)
    Xp = shared.X;
    [L,m,n,~] = size(Xp);
    total = L*m*n;
    k = max(1, round(level * total));
    idx = randperm(total, k);
    for t = 1:numel(idx)
        [l,i,j] = ind2sub([L,m,n], idx(t));
        block = squeeze(Xp(l,:,j,:));
        fillv = median(block, 1);
        Xp(l,i,j,:) = reshape(sanitize_ldf_entry(fillv), [1,1,1,4]);
    end
    pert = struct('shared', replace_X(shared, Xp));
end

function shared2 = replace_X(shared, Xnew)
    shared2 = shared;
    shared2.X = Xnew;
end

%% ============================= TRUST TOOLS ===============================
function T = shrink_trust(Tsim, Tneutral, alpha, epsVal)
    T = alpha * Tsim + (1 - alpha) * Tneutral;
    T = sanitize_row_stochastic_trust(T, epsVal);
end

function lambda = clamp_lambda(lambda)
    lambda = min(max(lambda(:), 0.05), 0.95);
end

function w = similarity_centrality_weights(S0, epsVal)
    T = build_trust_matrix_from_similarity(S0, epsVal);
    c = sum(T, 1).';
    c = max(c, epsVal);
    w = c / sum(c);
end

function T = sanitize_row_stochastic_trust(T, eps0)
    T = max(T, 0);
    T(1:size(T,1)+1:end) = 0;
    for i = 1:size(T,1)
        s = sum(T(i,:));
        if s <= eps0
            T(i,:) = 1;
            T(i,i) = 0;
            s = sum(T(i,:));
        end
        T(i,:) = T(i,:) / s;
    end
end

function e = row_entropy(T)
    e = zeros(size(T,1),1);
    for i = 1:size(T,1)
        r = T(i,:);
        r = r(r > 0);
        e(i) = -sum(r .* log(r)) / max(log(max(numel(r),2)), 1e-12);
    end
end

function s = offdiag_std(T)
    M = T(~eye(size(T,1)));
    if isempty(M)
        s = 0;
    else
        s = std(M, 0);
    end
end

%% ============================== SANITIZE =================================
function W = validate_weight_override(W, shared)
    if ~isequal(size(W), [double(shared.L), double(shared.n)])
        error('Weight override must have size [L,n].');
    end
    W = max(W, 1e-12);
    W = W ./ sum(W,2);
end

function X = sanitize_ldf_tensor(X)
    Y = reshape(X, [], 4);
    for r = 1:size(Y,1)
        Y(r,:) = sanitize_ldf_entry(Y(r,:));
    end
    X = reshape(Y, size(X));
end

function e = sanitize_ldf_entry(e)
    e = reshape(e, 1, 4);
    e = min(max(e, 0), 1);
    A = e(1); U = e(2); a = e(3); b = e(4);
    s = a + b;
    if s > 1
        a = a / s;
        b = b / s;
    elseif s < 1e-12
        a = 0.5; b = 0.5;
    end
    wab = a*A + b*U;
    if wab > 1
        scale = 0.999999 / wab;
        A = min(max(A * scale, 0), 1);
        U = min(max(U * scale, 0), 1);
    end
    e = [A,U,a,b];
end

%% ============================ CORE METHODS ===============================
function [AC, Pcond] = ldf_cpt_topsis_and_condprob(El, wCrit, costIdx, p)
    [m,n,~] = size(El);
    isCost = false(1,n); isCost(costIdx)=true;
    S = El;
    for j = 1:n
        if isCost(j)
            S(:,j,:) = complement_ldfn_any(S(:,j,:));
        end
    end
    sPlus  = zeros(n,4);
    sMinus = zeros(n,4);
    for j = 1:n
        Aj = S(:,j,1); Uj = S(:,j,2); aj = S(:,j,3); bj = S(:,j,4);
        sPlus(j,:)  = [max(Aj) min(Uj) max(aj) min(bj)];
        sMinus(j,:) = [min(Aj) max(Uj) min(aj) max(bj)];
    end
    Hplus  = zeros(m,n);
    Hminus = zeros(m,n);
    for i = 1:m
        for j = 1:n
            sij = reshape(S(i,j,:), [1,4]);
            dg = ndist_published(sij, sMinus(j,:));
            dl = ndist_published(sij, sPlus(j,:));
            Hplus(i,j)  = dg^p.alpha;
            Hminus(i,j) = -p.lambda*(dl^p.beta);
        end
    end
    if ~p.useAltWeighting
        piPlusPrime  = (wCrit.^p.gamma) ./ ((wCrit.^p.gamma + (1-wCrit).^p.gamma).^(1/p.gamma));
        piMinusPrime = (wCrit.^p.delta) ./ ((wCrit.^p.delta + (1-wCrit).^p.delta).^(1/p.delta));
    else
        piPlusPrime  = (wCrit.^p.gamma) .* ((wCrit.^p.gamma + (1-wCrit).^p.gamma).^(1/p.gamma));
        piMinusPrime = (wCrit.^p.delta) .* ((wCrit.^p.delta + (1-wCrit).^p.delta).^(1/p.delta));
    end
    piPlus  = piPlusPrime  ./ sum(piPlusPrime);
    piMinus = piMinusPrime ./ sum(piMinusPrime);
    HplusW  = Hplus  .* repmat(piPlus,  m, 1);
    HminusW = Hminus .* repmat(piMinus, m, 1);
    PIS = max(HminusW, [], 1);
    NIS = min(HplusW,  [], 1);
    dPlus  = sqrt(sum((HminusW - repmat(PIS,m,1)).^2, 2));
    dMinus = sqrt(sum((HplusW  - repmat(NIS,m,1)).^2, 2));
    AC = (dMinus ./ (dMinus + dPlus)).';
    Pcond = softmax_row(AC, 1.0);
end

function W = ldfdewm_weights(E, costIdx)
    [L,m,n,~] = size(E);
    isCost = false(1,n); isCost(costIdx) = true;
    S = E;
    for j = 1:n
        if isCost(j)
            S(:,:,j,:) = complement_ldfn_any(S(:,:,j,:));
        end
    end
    q = 2;
    denom = 2*m*log2(2^q - 1);
    e = zeros(L,n);
    for l = 1:L
        for j = 1:n
            s = 0;
            for i = 1:m
                x = reshape(S(l,i,j,:), [1,4]);
                s = s + ldfde_entropy_term(x);
            end
            e(l,j) = s / denom;
        end
    end
    d = 1 - e;
    W = d ./ sum(d,2);
end

function [Pr, Praw, cosMat, xiMat] = qpt_aggregate(Pcond, wExperts)
    [L,m] = size(Pcond);
    cosMat = eye(L);
    xiMat  = zeros(L);
    for l = 1:L
        for k = l+1:L
            Dl = Pcond(l,:); Dk = Pcond(k,:);
            xi = estimate_xi_cosine_heuristic(Dl, Dk);
            xiMat(l,k)=xi; xiMat(k,l)=xi;
            c = cos(xi);
            cosMat(l,k)=c; cosMat(k,l)=c;
        end
    end
    Praw = zeros(1,m);
    for i = 1:m
        base = sum(wExperts(:) .* Pcond(:,i));
        inter = 0;
        for l = 1:L
            for k = l+1:L
                inter = inter + 2 * sqrt(wExperts(l)*Pcond(l,i) * wExperts(k)*Pcond(k,i)) * cosMat(l,k);
            end
        end
        Praw(i) = base + inter;
    end
    Pr = Praw ./ sum(Praw);
end

function fj = fj_consensus_safe(S0, T, lambda, maxIter, tol)
    [L,~] = size(S0);
    rowSums = sum(T,2);
    if max(abs(rowSums - 1)) > 1e-10
        error('T must be row-stochastic.');
    end
    Lambda = diag(lambda(:));
    I = eye(L);
    Z = S0;
    for t = 1:maxIter
        Znew = Lambda * S0 + (I - Lambda) * T * Z;
        if max(abs(Znew(:) - Z(:))) < tol
            Z = Znew;
            break;
        end
        Z = Znew;
    end
    closedForm = (I - (I - Lambda) * T) \ (Lambda * S0);
    fj = struct('Zeq', Z, 'closedForm', closedForm, 'maxClosedFormError', max(abs(closedForm(:)-Z(:))));
end

function Srob = robustify_expert_signal_matrix(S0, robcfg)
    Srob = S0;
    eps0 = robcfg.eps;
    renormalize = logical(get_struct_field(robcfg, 'renormalize', true));
    for l = 1:size(S0,1)
        row = S0(l,:);
        switch lower(robcfg.mode)
            case 'none'
                row2 = row;
            case 'winsor'
                p = robcfg.winsorPct;
                method = get_struct_field(robcfg, 'quantileMethod', 'linear');
                lo = local_quantile(row, p, method);
                hi = local_quantile(row, 1-p, method);
                row2 = min(max(row, lo), hi);
            case 'huber'
                c = robcfg.huberC;
                medv = median(row);
                s = 1.4826 * local_mad(row);
                if s < eps0
                    row2 = row;
                else
                    z = (row - medv) / s;
                    z = min(max(z, -c), c);
                    row2 = medv + s * z;
                end
            case 'epsilon_floor'
                row2 = max(row, eps0);
            case 'uniform_shrink'
                eta = get_struct_field(robcfg, 'uniformShrinkWeight', 0.05);
                eta = min(max(eta, 0), 1);
                row2 = (1-eta) * row + eta * (ones(size(row)) / numel(row));
            otherwise
                error('Unknown robust mode: %s', robcfg.mode);
        end
        row2 = max(row2, eps0);
        if renormalize
            row2 = row2 / sum(row2);
        end
        Srob(l,:) = row2;
    end
end


function S = summarize_robustness_trials(T)
    if isempty(T)
        S = table();
        return;
    end

    grpVars = {'PerturbationFamily','ModelID','Level'};
    [G, grpTable] = findgroups(T(:, grpVars));
    nG = height(grpTable);

    nReps = zeros(nG,1);
    mean_Abs_dHG = zeros(nG,1);
    median_Abs_dHG = zeros(nG,1);
    mean_Abs_dNHG = zeros(nG,1);
    median_Abs_dNHG = zeros(nG,1);
    mean_SpearmanVsBase = zeros(nG,1);
    median_SpearmanVsBase = zeros(nG,1);
    mean_KendallVsBase = zeros(nG,1);
    median_KendallVsBase = zeros(nG,1);
    mean_Top1KeepBase = zeros(nG,1);
    median_Top1KeepBase = zeros(nG,1);
    mean_ExactRankKeepBase = zeros(nG,1);
    mean_Top2SetKeepBase = zeros(nG,1);
    mean_PairwiseReversalRate = zeros(nG,1);
    median_PairwiseReversalRate = zeros(nG,1);
    mean_ScoreL1Distance = zeros(nG,1);
    median_ScoreL1Distance = zeros(nG,1);
    mean_ScoreL2Distance = zeros(nG,1);
    median_ScoreL2Distance = zeros(nG,1);
    mean_DecisionRegret = zeros(nG,1);
    median_DecisionRegret = zeros(nG,1);

    for g = 1:nG
        idx = (G == g);
        nReps(g) = sum(idx);
        mean_Abs_dHG(g) = mean(T.Abs_dHG(idx));
        median_Abs_dHG(g) = median(T.Abs_dHG(idx));
        mean_Abs_dNHG(g) = mean(T.Abs_dNHG(idx));
        median_Abs_dNHG(g) = median(T.Abs_dNHG(idx));
        mean_SpearmanVsBase(g) = mean(T.SpearmanVsBase(idx));
        median_SpearmanVsBase(g) = median(T.SpearmanVsBase(idx));
        mean_KendallVsBase(g) = mean(T.KendallVsBase(idx));
        median_KendallVsBase(g) = median(T.KendallVsBase(idx));
        mean_Top1KeepBase(g) = mean(double(T.Top1KeepBase(idx)));
        median_Top1KeepBase(g) = median(double(T.Top1KeepBase(idx)));
        mean_ExactRankKeepBase(g) = mean(double(T.ExactRankKeepBase(idx)));
        mean_Top2SetKeepBase(g) = mean(double(T.Top2SetKeepBase(idx)));
        mean_PairwiseReversalRate(g) = mean(T.PairwiseReversalRate(idx));
        median_PairwiseReversalRate(g) = median(T.PairwiseReversalRate(idx));
        mean_ScoreL1Distance(g) = mean(T.ScoreL1Distance(idx));
        median_ScoreL1Distance(g) = median(T.ScoreL1Distance(idx));
        mean_ScoreL2Distance(g) = mean(T.ScoreL2Distance(idx));
        median_ScoreL2Distance(g) = median(T.ScoreL2Distance(idx));
        mean_DecisionRegret(g) = mean(T.DecisionRegret(idx));
        median_DecisionRegret(g) = median(T.DecisionRegret(idx));
    end

    S = [grpTable, table(nReps, mean_Abs_dHG, median_Abs_dHG, mean_Abs_dNHG, median_Abs_dNHG, ...
        mean_SpearmanVsBase, median_SpearmanVsBase, mean_KendallVsBase, median_KendallVsBase, ...
        mean_Top1KeepBase, median_Top1KeepBase, mean_ExactRankKeepBase, mean_Top2SetKeepBase, ...
        mean_PairwiseReversalRate, median_PairwiseReversalRate, mean_ScoreL1Distance, ...
        median_ScoreL1Distance, mean_ScoreL2Distance, median_ScoreL2Distance, ...
        mean_DecisionRegret, median_DecisionRegret)];
end

function P = summarize_paired_vs_reference(T, refID, targetID)
    if isempty(T)
        P = table();
        return;
    end

    metrics = {'Abs_dHG','Abs_dNHG','PairwiseReversalRate','ScoreL1Distance','ScoreL2Distance','DecisionRegret'};
    grpVars = {'CaseID','PerturbationFamily','Level'};
    [G, grpTable] = findgroups(T(:, grpVars));

    CaseID = strings(0,1);
    PerturbationFamily = strings(0,1);
    Level = zeros(0,1);
    Metric = strings(0,1);
    ReferenceModel = strings(0,1);
    TargetModel = strings(0,1);
    n = zeros(0,1);
    ReferenceMean = zeros(0,1);
    TargetMean = zeros(0,1);
    MeanDifference = zeros(0,1);
    CI95Low = zeros(0,1);
    CI95High = zeros(0,1);
    WinRate = zeros(0,1);
    LossRate = zeros(0,1);
    TieRate = zeros(0,1);
    CohenDz = zeros(0,1);

    for g = 1:height(grpTable)
        sub = T(G == g,:);
        ref = sub(sub.ModelID == string(refID),:);
        target = sub(sub.ModelID == string(targetID),:);
        if isempty(ref) || isempty(target)
            continue;
        end
        [~, ia, ib] = intersect(ref.Rep, target.Rep);
        for m = 1:numel(metrics)
            metric = metrics{m};
            x = ref.(metric)(ia);
            y = target.(metric)(ib);
            d = y - x;
            nn = numel(d);
            if nn == 0
                continue;
            end
            sd = std(d, 0);
            se = sd / sqrt(max(nn,1));

            CaseID(end+1,1) = string(grpTable.CaseID(g)); %#ok<AGROW>
            PerturbationFamily(end+1,1) = string(grpTable.PerturbationFamily(g)); %#ok<AGROW>
            Level(end+1,1) = grpTable.Level(g); %#ok<AGROW>
            Metric(end+1,1) = string(metric); %#ok<AGROW>
            ReferenceModel(end+1,1) = string(refID); %#ok<AGROW>
            TargetModel(end+1,1) = string(targetID); %#ok<AGROW>
            n(end+1,1) = nn; %#ok<AGROW>
            ReferenceMean(end+1,1) = mean(x); %#ok<AGROW>
            TargetMean(end+1,1) = mean(y); %#ok<AGROW>
            MeanDifference(end+1,1) = mean(d); %#ok<AGROW>
            CI95Low(end+1,1) = mean(d) - 1.96*se; %#ok<AGROW>
            CI95High(end+1,1) = mean(d) + 1.96*se; %#ok<AGROW>
            WinRate(end+1,1) = mean(y < x); %#ok<AGROW>
            LossRate(end+1,1) = mean(y > x); %#ok<AGROW>
            TieRate(end+1,1) = mean(y == x); %#ok<AGROW>
            if sd < 1e-12
                CohenDz(end+1,1) = NaN; %#ok<AGROW>
            else
                CohenDz(end+1,1) = mean(d) / sd; %#ok<AGROW>
            end
        end
    end

    P = table(CaseID, PerturbationFamily, Level, Metric, ReferenceModel, TargetModel, n, ...
        ReferenceMean, TargetMean, MeanDifference, CI95Low, CI95High, WinRate, LossRate, TieRate, CohenDz);
end

function S = summarize_ranking_stability(T)
    if isempty(T)
        S = table();
        return;
    end

    grpVars = {'CaseID','PerturbationFamily','ModelID'};
    [G, grpTable] = findgroups(T(:, grpVars));
    nG = height(grpTable);

    nRows = zeros(nG,1);
    mean_SpearmanVsBase = zeros(nG,1);
    mean_KendallVsBase = zeros(nG,1);
    Top1Retention = zeros(nG,1);
    ExactRankRetention = zeros(nG,1);
    Top2SetRetention = zeros(nG,1);
    mean_PairwiseReversalRate = zeros(nG,1);
    mean_ScoreL1Distance = zeros(nG,1);
    mean_ScoreL2Distance = zeros(nG,1);
    mean_DecisionRegret = zeros(nG,1);

    for g = 1:nG
        idx = (G == g);
        nRows(g) = sum(idx);
        mean_SpearmanVsBase(g) = mean(T.SpearmanVsBase(idx));
        mean_KendallVsBase(g) = mean(T.KendallVsBase(idx));
        Top1Retention(g) = mean(double(T.Top1KeepBase(idx)));
        ExactRankRetention(g) = mean(double(T.ExactRankKeepBase(idx)));
        Top2SetRetention(g) = mean(double(T.Top2SetKeepBase(idx)));
        mean_PairwiseReversalRate(g) = mean(T.PairwiseReversalRate(idx));
        mean_ScoreL1Distance(g) = mean(T.ScoreL1Distance(idx));
        mean_ScoreL2Distance(g) = mean(T.ScoreL2Distance(idx));
        mean_DecisionRegret(g) = mean(T.DecisionRegret(idx));
    end

    S = [grpTable, table(nRows, mean_SpearmanVsBase, mean_KendallVsBase, Top1Retention, ...
        ExactRankRetention, Top2SetRetention, mean_PairwiseReversalRate, mean_ScoreL1Distance, ...
        mean_ScoreL2Distance, mean_DecisionRegret)];
end

function s = local_mad(x)
    x = x(:);
    medx = median(x);
    s = median(abs(x - medx));
end

function out = merge_structs(base, override)
    out = base;
    if isempty(override)
        return;
    end
    f = fieldnames(override);
    for i = 1:numel(f)
        key = f{i};
        if isstruct(override.(key)) && isfield(out, key) && isstruct(out.(key))
            out.(key) = merge_structs(out.(key), override.(key));
        else
            out.(key) = override.(key);
        end
    end
end

%% ============================== HELPERS ==================================
function Xc = complement_ldfn_any(X)
    sz = size(X);
    Y  = reshape(X, [], 4);
    Yc = Y(:, [2 1 4 3]);
    Xc = reshape(Yc, sz);
end

function Ed = ldfde_entropy_term(x)
    x = reshape(x, [1,4]);
    A = x(1); U = x(2); a = x(3); b = x(4);
    q = 2;
    denom = (2^q - 1);
    t1 = max(a*A, 1e-12);
    t2 = max(b*U, 1e-12);
    Ed = -t1*log2(t1/denom) - t2*log2(t2/denom);
end

function d = ndist_published(x1, x2)
    part1 = sqrt(0.25*sum((x1-x2).^2));
    F = 2*log2(2^2 - 1);
    part2 = (1/F)*abs(ldfde_entropy_term(x1) - ldfde_entropy_term(x2));
    d = 0.5*part1 + 0.5*part2;
end

function p = softmax_row(x, tau)
    x = x(:).';
    z = tau * (x - max(x));
    ez = exp(z);
    p = ez ./ sum(ez);
end

function xi = estimate_xi_cosine_heuristic(Dl, Dk)
    Dl = Dl(:); Dk = Dk(:); Delta = Dl - Dk;
    nDl = max(norm(Dl), 1e-12); nDk = max(norm(Dk), 1e-12); nDe = max(norm(Delta), 1e-12);
    theta_Dl = acos(clamp_scalar((nDk^2 + nDe^2 - nDl^2) / (2*nDk*nDe)));
    theta_Dk = acos(clamp_scalar((nDl^2 + nDe^2 - nDk^2) / (2*nDl*nDe)));
    theta_De = acos(clamp_scalar((nDk^2 + nDl^2 - nDe^2) / (2*nDl*nDk)));
    Xi = (theta_De/theta_Dl) - (theta_Dk/theta_Dl);
    if Xi <= -2
        xi = 0;
    elseif Xi < 2
        xi = (pi/2) * (1 + 0.5*Xi);
    else
        xi = pi;
    end
end

function y = clamp_scalar(x)
    y = min(1, max(-1, x));
end

function T = build_neutral_trust(L)
    T = ones(L,L) - eye(L);
    T = T ./ sum(T,2);
end

function T = build_trust_matrix_from_similarity(S0, epsVal)
    [L,~] = size(S0);
    T = zeros(L,L);
    for i = 1:L
        xi = S0(i,:); nxi = norm(xi);
        for k = 1:L
            if i == k, continue; end
            xk = S0(k,:); nxk = norm(xk);
            denom = max(nxi*nxk, epsVal);
            T(i,k) = max(dot(xi,xk) / denom, 0);
        end
    end
    for i = 1:L
        s = sum(T(i,:));
        if s <= epsVal
            T(i,:) = 1; T(i,i)=0; s = sum(T(i,:));
        end
        T(i,:) = T(i,:) / s;
    end
end

function [rho, tau] = rank_correlation_from_orders(order1, order2)
    order1 = order1(:); order2 = order2(:);
    n = numel(order1);
    r1 = zeros(n,1); r2 = zeros(n,1);
    for i = 1:n
        r1(order1(i)) = i;
        r2(order2(i)) = i;
    end
    rho = 1 - 6*sum((r1-r2).^2) / (n*(n^2-1));
    C = 0; D = 0;
    for i = 1:n-1
        for j = i+1:n
            s = sign((r1(i)-r1(j))*(r2(i)-r2(j)));
            if s > 0
                C = C + 1;
            elseif s < 0
                D = D + 1;
            end
        end
    end
    tau = (C - D) / (n*(n-1)/2);
end

function ng = normalized_headgap(score, order)
    s = score(:);
    if numel(order) < 2
        ng = NaN; return;
    end
    s1 = s(order(1)); s2 = s(order(2)); sm = s(order(end));
    ng = (s1 - s2) / max(s1 - sm, 1e-12);
end

function hg = head_gap(score, order)
    s = score(:);
    hg = s(order(1)) - s(order(2));
end

function v = topk_set_keep(orderBase, orderPert, k)
    k = min([k, numel(orderBase), numel(orderPert)]);
    v = isequal(sort(orderBase(1:k)), sort(orderPert(1:k)));
end

function rate = pairwise_reversal_rate(orderBase, orderPert)
    orderBase = orderBase(:);
    orderPert = orderPert(:);
    n = numel(orderBase);
    r1 = zeros(n,1);
    r2 = zeros(n,1);
    for i = 1:n
        r1(orderBase(i)) = i;
        r2(orderPert(i)) = i;
    end
    total = n*(n-1)/2;
    if total == 0
        rate = 0;
        return;
    end
    rev = 0;
    for i = 1:n-1
        for j = i+1:n
            if sign(r1(i)-r1(j)) ~= sign(r2(i)-r2(j))
                rev = rev + 1;
            end
        end
    end
    rate = rev / total;
end

function val = get_struct_field(s, fieldName, defaultVal)
    if isstruct(s) && isfield(s, fieldName) && ~isempty(s.(fieldName))
        val = s.(fieldName);
    else
        val = defaultVal;
    end
end

function txt = format_numeric_row(x)
    x = x(:).';
    parts = cell(1, numel(x));
    for i = 1:numel(x)
        parts{i} = sprintf('%.10g', x(i));
    end
    txt = strjoin(parts, '; ');
end

function q = local_quantile(x, p, method)
    if nargin < 3 || isempty(method)
        method = 'linear';
    end
    xs = sort(x(:)); n = numel(xs);
    if n == 1, q = xs(1); return; end
    idx = 1 + (n-1)*p;
    switch lower(method)
        case 'linear'
            lo = floor(idx); hi = ceil(idx);
            if lo == hi
                q = xs(lo);
            else
                q = xs(lo) + (idx-lo)*(xs(hi)-xs(lo));
            end
        case 'nearest'
            q = xs(min(max(round(idx), 1), n));
        case 'lower'
            q = xs(min(max(floor(idx), 1), n));
        case 'higher'
            q = xs(min(max(ceil(idx), 1), n));
        otherwise
            error('Unknown quantile method: %s', method);
    end
end
