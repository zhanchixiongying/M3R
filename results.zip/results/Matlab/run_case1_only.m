
function result = run_case1_only(cfg)
%RUN_CASE1_ONLY Standalone runner for CASE1.
% Run this single file to reproduce the original integrated-suite results
% for CASE1 without depending on other .m files.
%
% Usage:
%   result = run_case1_only();
%   result = run_case1_only(cfg);

    if nargin < 1 || isempty(cfg)
        cfg = local_default_config();
    end
    rng(cfg.randomSeed, 'twister');

    shared = load_case_patient_capital_published();
    validate_case_contract(shared);
    cfg = adapt_cfg_to_case(shared, cfg);

    result = struct();
    result.caseID = shared.caseID;
    result.caseName = shared.caseName;
    result.shared = shared;
    result.audit = audit_case_input(shared);
    result.main = run_case_main_suite(shared, cfg);

    if cfg.sensitivity.enabled
        result.sensitivity = run_case_sensitivity_suite(shared, cfg, result.main);
    else
        result.sensitivity = struct();
    end

    if cfg.robustness.enabled
        result.robustness = run_case_robustness_suite(shared, cfg, result.main);
    else
        result.robustness = struct();
    end

    disp(' ');
    disp(['================ STANDALONE RUN FOR ' shared.caseID ' ================']);
    disp(result.main.summaryTable);
    disp('=================================================================');

    if cfg.saveOutputs
        if ~exist(cfg.outputDir, 'dir')
            mkdir(cfg.outputDir);
        end
        save(fullfile(cfg.outputDir, 'case1_standalone_result.mat'), 'result');
        writetable(result.main.summaryTable, fullfile(cfg.outputDir, 'case1_main_summary.csv'));
    end
end


function cfg = local_default_config()
    cfg = struct();

    cfg.randomSeed = 20260331;
    cfg.saveOutputs = false;
    cfg.outputDir = fullfile(pwd, 'eswa_outputs');

    cfg.main.modelIDs = {'M0','M1','M2','M3','M4','M5'};

    cfg.published = struct();
    cfg.published.cpt.alpha  = 0.88;
    cfg.published.cpt.beta   = 0.88;
    cfg.published.cpt.lambda = 2.25;
    cfg.published.cpt.gamma  = 0.61;
    cfg.published.cpt.delta  = 0.69;
    cfg.published.cpt.useAltWeighting = false;
    cfg.published.groupWeights = [1/3; 1/3; 1/3];

    cfg.newMethod = struct();
    cfg.newMethod.scoring.method = 'aa_minus_bu_shifted';
    cfg.newMethod.regret.eta = 0.88;
    cfg.newMethod.regret.delta = 0.70;
    cfg.newMethod.regret.referenceMode = 'criterion_max';
    cfg.newMethod.multimoora.epsShift = 1e-6;
    cfg.newMethod.multimoora.normalizeMode = 'minmax';
    cfg.newMethod.bridge.tau = 1.0;
    cfg.newMethod.consensus.lambdaNeutral = [0.50; 0.50; 0.50];
    cfg.newMethod.consensus.groupWeights = [1/3; 1/3; 1/3];
    cfg.newMethod.consensus.maxIter = 500;
    cfg.newMethod.consensus.tol = 1e-10;
    cfg.newMethod.consensus.similarityEps = 1e-12;

    cfg.sensitivity.enabled = true;
    cfg.sensitivity.models = {'M0','M4','M5'};
    cfg.sensitivity.M0.alphaGrid  = 0.70:0.05:1.00;
    cfg.sensitivity.M0.betaGrid   = 0.70:0.05:1.00;
    cfg.sensitivity.M0.lambdaGrid = 1.50:0.25:3.00;
    cfg.sensitivity.M0.gammaGrid  = 0.40:0.05:0.80;
    cfg.sensitivity.M0.deltaGrid  = 0.40:0.05:0.80;

    cfg.sensitivity.M4.etaGrid = 0.70:0.05:1.00;
    cfg.sensitivity.M4.deltaGrid = 0.20:0.10:1.50;
    cfg.sensitivity.M4.lambdaNeutralGrid = 0.20:0.10:0.80;
    cfg.sensitivity.M5.etaGrid = cfg.sensitivity.M4.etaGrid;
    cfg.sensitivity.M5.deltaGrid = cfg.sensitivity.M4.deltaGrid;
    cfg.sensitivity.M5.lambdaNeutralGrid = cfg.sensitivity.M4.lambdaNeutralGrid;

    cfg.robustness.enabled = true;
    cfg.robustness.models = {'M0','M4','M5'};
    cfg.robustness.repetitions = 500;
    cfg.robustness.noiseSigmas = [0.01 0.03 0.05];
    cfg.robustness.missingRates = [0.05 0.10 0.15];
    cfg.robustness.extremeFlipRates = [0.02 0.05 0.10];
end

function shared = load_case_patient_capital_published()
    shared = load_shared_case1_input();
    shared.caseID = 'CASE1';
    shared.caseName = 'Patient-capital published case';
    shared.sourceType = 'published_code_input';
    shared.hasPublishedReference = true;
    shared.reference = struct();
    shared.reference.publishedRanking = {'X1','X3','X4','X2'};
    shared.reference.publishedWeights = [
        0.180917 0.180917 0.126655 0.257850 0.253661;
        0.210978 0.251220 0.083600 0.200200 0.253999;
        0.253603 0.240676 0.124192 0.138842 0.242687];
end

function shared = load_shared_case1_input()
    shared = struct();
    shared.experts = {'D1','D2','D3'};
    shared.alternatives = {'X1','X2','X3','X4'};
    shared.criteria = {'C1','C2','C3','C4','C5'};
    shared.L = 3; shared.m = 4; shared.n = 5;
    shared.costIdx = 5;
    shared.costCriteria = logical([0 0 0 0 1]);

    X = zeros(shared.L, shared.m, shared.n, 4);

    % ----- D1 -----
    X(1,1,1,:) = [0.88 0.41 0.70 0.30];
    X(1,1,2,:) = [0.99 0.25 0.80 0.20];
    X(1,1,3,:) = [0.88 0.41 0.70 0.30];
    X(1,1,4,:) = [0.88 0.41 0.70 0.30];
    X(1,1,5,:) = [0.79 0.53 0.60 0.40];

    X(1,2,1,:) = [0.55 0.71 0.40 0.60];
    X(1,2,2,:) = [0.64 0.62 0.50 0.50];
    X(1,2,3,:) = [0.55 0.71 0.40 0.60];
    X(1,2,4,:) = [0.27 0.85 0.30 0.70];
    X(1,2,5,:) = [0.27 0.85 0.30 0.70];

    X(1,3,1,:) = [0.88 0.41 0.70 0.30];
    X(1,3,2,:) = [0.79 0.53 0.60 0.40];
    X(1,3,3,:) = [0.88 0.41 0.70 0.30];
    X(1,3,4,:) = [0.88 0.41 0.70 0.30];
    X(1,3,5,:) = [0.88 0.41 0.70 0.30];

    X(1,4,1,:) = [0.55 0.71 0.40 0.60];
    X(1,4,2,:) = [0.79 0.53 0.60 0.40];
    X(1,4,3,:) = [0.88 0.41 0.70 0.30];
    X(1,4,4,:) = [0.64 0.62 0.50 0.50];
    X(1,4,5,:) = [0.55 0.71 0.40 0.60];

    % ----- D2 -----
    X(2,1,1,:) = [0.88 0.41 0.70 0.30];
    X(2,1,2,:) = [0.99 0.25 0.80 0.20];
    X(2,1,3,:) = [0.88 0.41 0.70 0.30];
    X(2,1,4,:) = [0.88 0.41 0.70 0.30];
    X(2,1,5,:) = [0.99 0.25 0.80 0.20];

    X(2,2,1,:) = [0.27 0.85 0.30 0.70];
    X(2,2,2,:) = [0.27 0.85 0.30 0.70];
    X(2,2,3,:) = [0.64 0.62 0.50 0.50];
    X(2,2,4,:) = [0.27 0.85 0.30 0.70];
    X(2,2,5,:) = [0.15 0.95 0.20 0.80];

    X(2,3,1,:) = [0.88 0.41 0.70 0.30];
    X(2,3,2,:) = [0.64 0.62 0.50 0.50];
    X(2,3,3,:) = [0.88 0.41 0.70 0.30];
    X(2,3,4,:) = [0.55 0.71 0.40 0.60];
    X(2,3,5,:) = [0.88 0.41 0.70 0.30];

    X(2,4,1,:) = [0.64 0.62 0.50 0.50];
    X(2,4,2,:) = [0.55 0.71 0.40 0.60];
    X(2,4,3,:) = [0.88 0.41 0.70 0.30];
    X(2,4,4,:) = [0.64 0.62 0.50 0.50];
    X(2,4,5,:) = [0.79 0.53 0.60 0.40];

    % ----- D3 -----
    X(3,1,1,:) = [0.88 0.41 0.70 0.30];
    X(3,1,2,:) = [0.99 0.25 0.80 0.20];
    X(3,1,3,:) = [0.88 0.41 0.70 0.30];
    X(3,1,4,:) = [0.88 0.41 0.70 0.30];
    X(3,1,5,:) = [0.79 0.53 0.60 0.40];

    X(3,2,1,:) = [0.15 0.95 0.20 0.80];
    X(3,2,2,:) = [0.27 0.85 0.30 0.70];
    X(3,2,3,:) = [0.55 0.71 0.40 0.60];
    X(3,2,4,:) = [0.55 0.71 0.40 0.60];
    X(3,2,5,:) = [0.15 0.95 0.20 0.80];

    X(3,3,1,:) = [0.88 0.41 0.70 0.30];
    X(3,3,2,:) = [0.79 0.53 0.60 0.40];
    X(3,3,3,:) = [0.64 0.62 0.50 0.50];
    X(3,3,4,:) = [0.79 0.53 0.60 0.40];
    X(3,3,5,:) = [0.88 0.41 0.70 0.30];

    X(3,4,1,:) = [0.55 0.71 0.40 0.60];
    X(3,4,2,:) = [0.64 0.62 0.50 0.50];
    X(3,4,3,:) = [0.88 0.41 0.70 0.30];
    X(3,4,4,:) = [0.55 0.71 0.40 0.60];
    X(3,4,5,:) = [0.64 0.62 0.50 0.50];

    shared.X = X;
end

%% ================================ CASE2 ==================================

function validate_case_contract(shared)
    requiredFields = {'X','L','m','n','experts','alternatives','criteria','costCriteria','costIdx','caseID','caseName','sourceType'};
    for i = 1:numel(requiredFields)
        if ~isfield(shared, requiredFields{i})
            error('Missing shared.%s', requiredFields{i});
        end
    end

    validateattributes(shared.X, {'double'}, {'real','finite','>=',0,'<=',1}, mfilename, 'shared.X');
    sz = size(shared.X);
    if numel(sz) ~= 4 || sz(4) ~= 4
        error('shared.X must be [L,m,n,4].');
    end
    if any(sz(1:3) ~= [shared.L, shared.m, shared.n])
        error('Size(shared.X) and [L,m,n] do not match.');
    end

    if numel(shared.experts) ~= shared.L
        error('Number of experts does not match L.');
    end
    if numel(shared.alternatives) ~= shared.m
        error('Number of alternatives does not match m.');
    end
    if numel(shared.criteria) ~= shared.n
        error('Number of criteria does not match n.');
    end
    if numel(shared.costCriteria) ~= shared.n
        error('costCriteria must have length n.');
    end

    idxFromMask = find(logical(shared.costCriteria));
    idxGiven = unique(shared.costIdx(:).');
    if ~isequal(idxFromMask, idxGiven)
        error('costIdx does not match costCriteria.');
    end
end

function audit = audit_case_input(shared)
    validate_case_contract(shared);
    audit = struct();
    audit.caseID = shared.caseID;
    audit.caseName = shared.caseName;
    audit.shape = size(shared.X);
    audit.numExperts = shared.L;
    audit.numAlternatives = shared.m;
    audit.numCriteria = shared.n;
    audit.costIdx = shared.costIdx(:).';
    audit.maxValue = max(shared.X(:));
    audit.minValue = min(shared.X(:));
    audit.isReady = true;
    audit.sourceType = shared.sourceType;
    if isfield(shared, 'rawRepresentation')
        audit.rawRepresentation = shared.rawRepresentation;
    else
        audit.rawRepresentation = 'native_LDF';
    end
end

%% ================================ CASE1 ==================================

function cfgOut = adapt_cfg_to_case(shared, cfgIn)
    cfgOut = cfgIn;
    L = double(shared.L);

    % Adapt only expert-dimension vectors. This leaves CASE1 and CASE2
    % unchanged because both already have L = 3 in the current code.
    if numel(cfgOut.published.groupWeights) ~= L
        cfgOut.published.groupWeights = ones(L,1) / L;
    end

    if numel(cfgOut.newMethod.consensus.groupWeights) ~= L
        cfgOut.newMethod.consensus.groupWeights = ones(L,1) / L;
    end

    if numel(cfgOut.newMethod.consensus.lambdaNeutral) ~= L
        lambda0 = cfgOut.newMethod.consensus.lambdaNeutral(:);
        if numel(lambda0) == 1
            cfgOut.newMethod.consensus.lambdaNeutral = lambda0(1) * ones(L,1);
        else
            cfgOut.newMethod.consensus.lambdaNeutral = 0.5 * ones(L,1);
        end
    end
end

function out = run_case_main_suite(shared, cfg)
    modelIDs = cfg.main.modelIDs;
    allResults = struct();

    for k = 1:numel(modelIDs)
        id = modelIDs{k};
        r = run_model_by_id(id, shared, cfg);
        validate_model_result_contract(r, shared, id);
        allResults.(id) = r;
    end

    baseOrder = allResults.M0.order(:);

    ModelID = strings(numel(modelIDs),1);
    Mode = strings(numel(modelIDs),1);
    NumAlternatives = zeros(numel(modelIDs),1);
    Top1 = strings(numel(modelIDs),1);
    Ranking = strings(numel(modelIDs),1);
    HeadGap = nan(numel(modelIDs),1);
    SpearmanVsM0 = nan(numel(modelIDs),1);
    KendallVsM0 = nan(numel(modelIDs),1);

    for k = 1:numel(modelIDs)
        id = modelIDs{k};
        r = allResults.(id);
        ModelID(k) = string(id);
        Mode(k) = string(r.mode);
        NumAlternatives(k) = numel(r.groupScore);
        Top1(k) = string(r.finalRanking{1});
        Ranking(k) = string(strjoin(r.finalRanking(:).', ' > '));
        HeadGap(k) = r.groupScore(r.order(1)) - r.groupScore(r.order(2));
        [SpearmanVsM0(k), KendallVsM0(k)] = rank_correlation_from_orders(baseOrder, r.order(:));
    end

    summaryTable = table(ModelID, Mode, NumAlternatives, Top1, Ranking, HeadGap, SpearmanVsM0, KendallVsM0);

    out = struct();
    out.allResults = allResults;
    out.summaryTable = summaryTable;
end

function validate_model_result_contract(r, shared, id)
    req = {'modelID','mode','groupScore','order','finalRanking','sortedScore'};
    for i = 1:numel(req)
        if ~isfield(r, req{i})
            error('Model %s missing result field: %s', id, req{i});
        end
    end
    if numel(r.groupScore) ~= shared.m
        error('Model %s returned groupScore with wrong length.', id);
    end
    if numel(r.order) ~= shared.m
        error('Model %s returned order with wrong length.', id);
    end
    if numel(r.finalRanking) ~= shared.m
        error('Model %s returned finalRanking with wrong length.', id);
    end
end

function r = run_model_by_id(id, shared, cfg)
    switch id
        case 'M0', r = model_M0_published(shared, cfg);
        case 'M1', r = model_M1_dmwm_cpt_qpt(shared, cfg);
        case 'M2', r = model_M2_ldfdewm_regret_qpt(shared, cfg);
        case 'M3', r = model_M3_ldfdewm_cpt_fj_neutral(shared, cfg);
        case 'M4', r = model_M4_new_full_fj_neutral(shared, cfg);
        case 'M5', r = model_M5_new_full_fj_similarity(shared, cfg);
        otherwise, error('Unsupported model ID: %s', id);
    end
end

%% ================================ MODELS =================================

function out = model_M0_published(shared, cfg)
    X = shared.X;
    W = ldfdewm_weights(X, shared.costIdx);

    Pcond = zeros(shared.L, shared.m);
    AC = zeros(shared.L, shared.m);
    for l = 1:shared.L
        El = reshape(X(l,:,:,:), [shared.m, shared.n, 4]);
        [AC(l,:), Pcond(l,:)] = ldf_cpt_topsis_and_condprob(El, W(l,:), shared.costIdx, cfg.published.cpt);
    end

    [Pr, Praw, cosMat, xiMat] = qpt_aggregate(Pcond, cfg.published.groupWeights);

    [sortedScore, order] = sort(Pr(:), 'descend');
    out = struct();
    out.modelID = 'M0';
    out.mode = 'published_baseline';
    out.weights = W;
    out.AC = AC;
    out.Pcond = Pcond;
    out.Praw = Praw;
    out.cosMat = cosMat;
    out.xiMat = xiMat;
    out.groupScore = Pr(:);
    out.order = order(:);
    out.finalRanking = shared.alternatives(order).';
    out.sortedScore = sortedScore;
end

function out = model_M1_dmwm_cpt_qpt(shared, cfg)
    Xn = normalize_cost_criteria(shared.X, shared.costCriteria);
    stage2 = compute_ldf_dmwm_weights(Xn);
    W = stage2.weights;

    Pcond = zeros(shared.L, shared.m);
    AC = zeros(shared.L, shared.m);
    for l = 1:shared.L
        El = reshape(shared.X(l,:,:,:), [shared.m, shared.n, 4]);
        [AC(l,:), Pcond(l,:)] = ldf_cpt_topsis_and_condprob(El, W(l,:), shared.costIdx, cfg.published.cpt);
    end

    [Pr, Praw, cosMat, xiMat] = qpt_aggregate(Pcond, cfg.published.groupWeights);

    [sortedScore, order] = sort(Pr(:), 'descend');
    out = struct();
    out.modelID = 'M1';
    out.mode = 'dmwm_cpt_qpt';
    out.weights = W;
    out.AC = AC;
    out.Pcond = Pcond;
    out.Praw = Praw;
    out.cosMat = cosMat;
    out.xiMat = xiMat;
    out.groupScore = Pr(:);
    out.order = order(:);
    out.finalRanking = shared.alternatives(order).';
    out.sortedScore = sortedScore;
end

function out = model_M2_ldfdewm_regret_qpt(shared, cfg)
    W = ldfdewm_weights(shared.X, shared.costIdx);
    Xn = normalize_cost_criteria(shared.X, shared.costCriteria);
    stage3 = compute_ldf_score_matrix(Xn, cfg.newMethod.scoring);
    stage4 = apply_regret_transform(stage3.Y, cfg.newMethod.regret);

    expertComposite = zeros(shared.L, shared.m);
    Pcond = zeros(shared.L, shared.m);
    expertDetails = cell(shared.L,1);
    for l = 1:shared.L
        Vl = reshape(stage4.V(l,:,:), [shared.m, shared.n]);
        expertDetails{l} = multimoora_from_regret(Vl, W(l,:), cfg.newMethod.multimoora);
        expertComposite(l,:) = expertDetails{l}.Composite(:).';
        Pcond(l,:) = softmax_row(expertComposite(l,:), cfg.newMethod.bridge.tau);
    end

    [Pr, Praw, cosMat, xiMat] = qpt_aggregate(Pcond, cfg.published.groupWeights);

    [sortedScore, order] = sort(Pr(:), 'descend');
    out = struct();
    out.modelID = 'M2';
    out.mode = 'ldfdewm_regret_qpt';
    out.weights = W;
    out.expertComposite = expertComposite;
    out.Pcond = Pcond;
    out.expertDetails = expertDetails;
    out.Praw = Praw;
    out.cosMat = cosMat;
    out.xiMat = xiMat;
    out.groupScore = Pr(:);
    out.order = order(:);
    out.finalRanking = shared.alternatives(order).';
    out.sortedScore = sortedScore;
end

function out = model_M3_ldfdewm_cpt_fj_neutral(shared, cfg)
    X = shared.X;
    W = ldfdewm_weights(X, shared.costIdx);

    Pcond = zeros(shared.L, shared.m);
    AC = zeros(shared.L, shared.m);
    for l = 1:shared.L
        El = reshape(X(l,:,:,:), [shared.m, shared.n, 4]);
        [AC(l,:), Pcond(l,:)] = ldf_cpt_topsis_and_condprob(El, W(l,:), shared.costIdx, cfg.published.cpt);
    end

    S0 = Pcond;
    T = build_neutral_trust(shared.L);
    lambda = cfg.newMethod.consensus.lambdaNeutral;
    fj = fj_consensus_safe(S0, T, lambda, cfg.newMethod.consensus.maxIter, cfg.newMethod.consensus.tol);

    groupScore = fj.Zeq.' * cfg.newMethod.consensus.groupWeights;
    [sortedScore, order] = sort(groupScore(:), 'descend');

    out = struct();
    out.modelID = 'M3';
    out.mode = 'ldfdewm_cpt_fj_neutral';
    out.weights = W;
    out.AC = AC;
    out.Pcond = Pcond;
    out.T = T;
    out.lambda = lambda;
    out.fj = fj;
    out.groupScore = groupScore(:);
    out.order = order(:);
    out.finalRanking = shared.alternatives(order).';
    out.sortedScore = sortedScore;
end

function out = model_M4_new_full_fj_neutral(shared, cfg)
    Xn = normalize_cost_criteria(shared.X, shared.costCriteria);
    stage2 = compute_ldf_dmwm_weights(Xn);
    W = stage2.weights;
    stage3 = compute_ldf_score_matrix(Xn, cfg.newMethod.scoring);
    stage4 = apply_regret_transform(stage3.Y, cfg.newMethod.regret);

    expertComposite = zeros(shared.L, shared.m);
    expertDetails = cell(shared.L,1);
    for l = 1:shared.L
        Vl = reshape(stage4.V(l,:,:), [shared.m, shared.n]);
        expertDetails{l} = multimoora_from_regret(Vl, W(l,:), cfg.newMethod.multimoora);
        expertComposite(l,:) = expertDetails{l}.Composite(:).';
    end

    S0 = expertComposite;
    T = build_neutral_trust(shared.L);
    lambda = cfg.newMethod.consensus.lambdaNeutral;
    fj = fj_consensus_safe(S0, T, lambda, cfg.newMethod.consensus.maxIter, cfg.newMethod.consensus.tol);

    groupScore = fj.Zeq.' * cfg.newMethod.consensus.groupWeights;
    [sortedScore, order] = sort(groupScore(:), 'descend');

    out = struct();
    out.modelID = 'M4';
    out.mode = 'new_full_fj_neutral';
    out.weights = W;
    out.expertComposite = expertComposite;
    out.expertDetails = expertDetails;
    out.T = T;
    out.lambda = lambda;
    out.fj = fj;
    out.groupScore = groupScore(:);
    out.order = order(:);
    out.finalRanking = shared.alternatives(order).';
    out.sortedScore = sortedScore;
end

function out = model_M5_new_full_fj_similarity(shared, cfg)
    Xn = normalize_cost_criteria(shared.X, shared.costCriteria);
    stage2 = compute_ldf_dmwm_weights(Xn);
    W = stage2.weights;
    stage3 = compute_ldf_score_matrix(Xn, cfg.newMethod.scoring);
    stage4 = apply_regret_transform(stage3.Y, cfg.newMethod.regret);

    expertComposite = zeros(shared.L, shared.m);
    expertDetails = cell(shared.L,1);
    for l = 1:shared.L
        Vl = reshape(stage4.V(l,:,:), [shared.m, shared.n]);
        expertDetails{l} = multimoora_from_regret(Vl, W(l,:), cfg.newMethod.multimoora);
        expertComposite(l,:) = expertDetails{l}.Composite(:).';
    end

    S0 = expertComposite;
    T = build_trust_matrix_from_similarity(S0, cfg.newMethod.consensus.similarityEps);
    lambda = cfg.newMethod.consensus.lambdaNeutral;
    fj = fj_consensus_safe(S0, T, lambda, cfg.newMethod.consensus.maxIter, cfg.newMethod.consensus.tol);

    groupScore = fj.Zeq.' * cfg.newMethod.consensus.groupWeights;
    [sortedScore, order] = sort(groupScore(:), 'descend');

    out = struct();
    out.modelID = 'M5';
    out.mode = 'new_full_fj_similarity';
    out.weights = W;
    out.expertComposite = expertComposite;
    out.expertDetails = expertDetails;
    out.T = T;
    out.lambda = lambda;
    out.fj = fj;
    out.groupScore = groupScore(:);
    out.order = order(:);
    out.finalRanking = shared.alternatives(order).';
    out.sortedScore = sortedScore;
end

%% ============================= CORE METHODS ==============================

function stage2 = compute_ldf_dmwm_weights(Xn)
    [L,m,n,~] = size(Xn);
    avgD = zeros(L,n);

    for l = 1:L
        Xe = get_expert_block(Xn, l);
        for j = 1:n
            pairDistances = zeros(nchoosek(m,2), 1);
            idx = 1;
            for i = 1:m-1
                for k = i+1:m
                    e1 = get_ldf_entry(Xe, i, j);
                    e2 = get_ldf_entry(Xe, k, j);
                    pairDistances(idx) = compute_ldf_distance(e1, e2);
                    idx = idx + 1;
                end
            end
            avgD(l,j) = (2/(m*(m-1))) * sum(pairDistances);
        end
    end

    W = zeros(L,n);
    for l = 1:L
        rowSum = sum(avgD(l,:));
        if rowSum <= 0
            error('Average distances sum to zero for expert %d.', l);
        end
        W(l,:) = avgD(l,:) / rowSum;
    end

    stage2 = struct();
    stage2.averageDistances = avgD;
    stage2.weights = W;
end

function stage3 = compute_ldf_score_matrix(Xn, scoring)
    [L,m,n,~] = size(Xn);
    Y = zeros(L,m,n);

    for l = 1:L
        Xe = get_expert_block(Xn, l);
        for i = 1:m
            for j = 1:n
                e = get_ldf_entry(Xe, i, j);
                A = e(1); U = e(2); a = e(3); b = e(4);
                switch lower(scoring.method)
                    case 'aa_minus_bu_shifted'
                        Y(l,i,j) = (1 + a*A - b*U) / 2;
                    otherwise
                        error('Unknown scoring.method: %s', scoring.method);
                end
            end
        end
    end

    stage3 = struct();
    stage3.Y = Y;
end

function stage4 = apply_regret_transform(Y, regretParams)
    eta = regretParams.eta;
    delta = regretParams.delta;

    U = Y .^ eta;
    switch lower(regretParams.referenceMode)
        case 'criterion_max'
            uRef = max(U, [], 2);
        otherwise
            error('Unknown regret reference mode: %s', regretParams.referenceMode);
    end

    G = 1 - exp(-delta .* bsxfun(@minus, U, uRef));
    V = U + G;

    stage4 = struct();
    stage4.U = U;
    stage4.uRef = uRef;
    stage4.G = G;
    stage4.V = V;
end

function out = multimoora_from_regret(V, w, params)
    [m,n] = size(V);
    w = w(:).';
    if abs(sum(w)-1) > 1e-8
        error('Weight vector must sum to 1.');
    end

    denom = sqrt(sum(V.^2, 1));
    denom(denom < params.epsShift) = 1;
    Z = bsxfun(@rdivide, V, denom);
    RS = Z * w.';

    ref = max(V, [], 1);
    RPraw = max(bsxfun(@times, abs(bsxfun(@minus, V, ref)), w), [], 2);

    Vshift = zeros(m,n);
    for j = 1:n
        col = V(:,j);
        cmin = min(col);
        cmax = max(col);
        if abs(cmax - cmin) < params.epsShift
            Vshift(:,j) = ones(m,1);
        else
            switch lower(params.normalizeMode)
                case 'minmax'
                    Vshift(:,j) = (col - cmin) ./ (cmax - cmin) + params.epsShift;
                otherwise
                    error('Unknown multimoora.normalizeMode: %s', params.normalizeMode);
            end
        end
    end
    FMFlog = log(Vshift) * w.';

    RSn = local_minmax(RS);
    RPn = 1 - local_minmax(RPraw);
    FMFn = local_minmax(FMFlog);
    Composite = (RSn + RPn + FMFn) / 3;

    [~, Rank] = sort(Composite, 'descend');

    out = struct();
    out.Z = Z;
    out.RS = RS;
    out.RPraw = RPraw;
    out.Vshift = Vshift;
    out.FMFlog = FMFlog;
    out.RSn = RSn;
    out.RPn = RPn;
    out.FMFn = FMFn;
    out.Composite = Composite;
    out.Rank = Rank(:);
end

function [AC, Pcond] = ldf_cpt_topsis_and_condprob(El, wCrit, costIdx, p)
    [m,n,~] = size(El);
    isCost = false(1,n); isCost(costIdx)=true;

    S = El;
    for j = 1:n
        if isCost(j)
            S(:,j,:) = complement_ldfn_any(S(:,j,:));
        end
    end

    sPlus  = zeros(n,4);
    sMinus = zeros(n,4);
    for j = 1:n
        Aj = S(:,j,1); Uj = S(:,j,2); aj = S(:,j,3); bj = S(:,j,4);
        sPlus(j,:)  = [max(Aj) min(Uj) max(aj) min(bj)];
        sMinus(j,:) = [min(Aj) max(Uj) min(aj) max(bj)];
    end

    Hplus  = zeros(m,n);
    Hminus = zeros(m,n);
    for i = 1:m
        for j = 1:n
            sij = reshape(S(i,j,:), [1,4]);
            dg = ndist_published(sij, sMinus(j,:));
            dl = ndist_published(sij, sPlus(j,:));
            Hplus(i,j)  = dg^p.alpha;
            Hminus(i,j) = -p.lambda*(dl^p.beta);
        end
    end

    if ~p.useAltWeighting
        piPlusPrime  = (wCrit.^p.gamma) ./ ((wCrit.^p.gamma + (1-wCrit).^p.gamma).^(1/p.gamma));
        piMinusPrime = (wCrit.^p.delta) ./ ((wCrit.^p.delta + (1-wCrit).^p.delta).^(1/p.delta));
    else
        piPlusPrime  = (wCrit.^p.gamma) .* ((wCrit.^p.gamma + (1-wCrit).^p.gamma).^(1/p.gamma));
        piMinusPrime = (wCrit.^p.delta) .* ((wCrit.^p.delta + (1-wCrit).^p.delta).^(1/p.delta));
    end
    piPlus  = piPlusPrime  ./ sum(piPlusPrime);
    piMinus = piMinusPrime ./ sum(piMinusPrime);

    HplusW  = Hplus  .* repmat(piPlus,  m, 1);
    HminusW = Hminus .* repmat(piMinus, m, 1);

    PIS = max(HminusW, [], 1);
    NIS = min(HplusW,  [], 1);

    dPlus  = sqrt(sum((HminusW - repmat(PIS,m,1)).^2, 2));
    dMinus = sqrt(sum((HplusW  - repmat(NIS,m,1)).^2, 2));

    AC = (dMinus ./ (dMinus + dPlus)).';
    Pcond = softmax_row(AC, 1.0);
end

function W = ldfdewm_weights(E, costIdx)
    [L,m,n,~] = size(E);
    isCost = false(1,n); isCost(costIdx) = true;
    S = E;
    for j = 1:n
        if isCost(j)
            S(:,:,j,:) = complement_ldfn_any(S(:,:,j,:));
        end
    end
    q = 2;
    denom = 2*m*log2(2^q - 1);
    e = zeros(L,n);
    for l = 1:L
        for j = 1:n
            s = 0;
            for i = 1:m
                x = reshape(S(l,i,j,:), [1,4]);
                s = s + ldfde_entropy_term(x);
            end
            e(l,j) = s / denom;
        end
    end
    d = 1 - e;
    W = d ./ sum(d,2);
end

function [Pr, Praw, cosMat, xiMat] = qpt_aggregate(Pcond, wExperts)
    [L,m] = size(Pcond);
    cosMat = eye(L);
    xiMat  = zeros(L);

    for l = 1:L
        for k = l+1:L
            Dl = Pcond(l,:);
            Dk = Pcond(k,:);
            xi = estimate_xi_cosine_heuristic(Dl, Dk);
            xiMat(l,k)=xi; xiMat(k,l)=xi;
            c = cos(xi);
            cosMat(l,k)=c; cosMat(k,l)=c;
        end
    end

    Praw = zeros(1,m);
    for i = 1:m
        base = sum(wExperts(:) .* Pcond(:,i));
        inter = 0;
        for l = 1:L
            for k = l+1:L
                inter = inter + 2 * sqrt(wExperts(l)*Pcond(l,i) * wExperts(k)*Pcond(k,i)) * cosMat(l,k);
            end
        end
        Praw(i) = base + inter;
    end

    Pr = Praw ./ sum(Praw);
end

function stage7 = fj_consensus_safe(S0, T, lambda, maxIter, tol)
    [L,~] = size(S0);
    rowSums = sum(T,2);
    if max(abs(rowSums - 1)) > 1e-10
        error('T must be row-stochastic.');
    end
    Lambda = diag(lambda);
    I = eye(L);

    Z = S0;
    history = {Z};
    for t = 1:maxIter
        Znew = Lambda * S0 + (I - Lambda) * T * Z;
        history{end+1,1} = Znew; %#ok<AGROW>
        if max(abs(Znew(:) - Z(:))) < tol
            Z = Znew;
            break;
        end
        Z = Znew;
    end

    closedForm = (I - (I - Lambda) * T) \ (Lambda * S0);
    err = max(abs(closedForm(:) - Z(:)));

    stage7 = struct();
    stage7.Zeq = Z;
    stage7.history = history;
    stage7.iterations = numel(history)-1;
    stage7.closedForm = closedForm;
    stage7.maxClosedFormError = err;
end

%% ============================== SENSITIVITY ==============================

function out = run_case_sensitivity_suite(shared, cfg, mainResults)
    out = run_sensitivity_suite(shared, cfg, mainResults);
    out.compact = struct();
    if isfield(out, 'M0')
        out.compact.M0 = compact_sensitivity_table(out.M0.table);
    end
    if isfield(out, 'M4')
        out.compact.M4 = compact_sensitivity_table(out.M4.table);
    end
    if isfield(out, 'M5')
        out.compact.M5 = compact_sensitivity_table(out.M5.table);
    end
end

function out = run_sensitivity_suite(shared, cfg, mainResults)
    modelIDs = cfg.sensitivity.models;
    out = struct();
    baseM0Order = mainResults.allResults.M0.order(:);

    for k = 1:numel(modelIDs)
        id = modelIDs{k};
        switch id
            case 'M0'
                out.M0 = sweep_M0(shared, cfg, baseM0Order);
            case 'M4'
                out.M4 = sweep_M4(shared, cfg, baseM0Order, false);
            case 'M5'
                out.M5 = sweep_M4(shared, cfg, baseM0Order, true);
            otherwise
                error('Unsupported sensitivity model: %s', id);
        end
    end
end

function result = sweep_M0(shared, cfg, baseOrder)
    rows = {};
    rankStrings = {};
    rhoList = [];
    tauList = [];
    top1List = {};
    topGapList = [];
    alphaList = []; betaList = []; lambdaList = []; gammaList = []; deltaList = [];

    p0 = cfg.published.cpt;
    for alpha = cfg.sensitivity.M0.alphaGrid
        p = p0; p.alpha = alpha;
        tmp = cfg; tmp.published.cpt = p;
        r = model_M0_published(shared, tmp);
        rows{end+1,1} = 'alpha'; rankStrings{end+1,1}=strjoin(r.finalRanking(:).', ' > '); %#ok<AGROW>
        alphaList(end+1,1)=alpha; betaList(end+1,1)=NaN; lambdaList(end+1,1)=NaN; gammaList(end+1,1)=NaN; deltaList(end+1,1)=NaN; %#ok<AGROW>
        [rho,tau]=rank_correlation_from_orders(baseOrder,r.order(:)); rhoList(end+1,1)=rho; tauList(end+1,1)=tau; %#ok<AGROW>
        top1List{end+1,1}=r.finalRanking{1}; topGapList(end+1,1)=r.groupScore(r.order(1))-r.groupScore(r.order(2)); %#ok<AGROW>
    end
    for beta = cfg.sensitivity.M0.betaGrid
        p = p0; p.beta = beta;
        tmp = cfg; tmp.published.cpt = p;
        r = model_M0_published(shared, tmp);
        rows{end+1,1} = 'beta'; rankStrings{end+1,1}=strjoin(r.finalRanking(:).', ' > '); %#ok<AGROW>
        alphaList(end+1,1)=NaN; betaList(end+1,1)=beta; lambdaList(end+1,1)=NaN; gammaList(end+1,1)=NaN; deltaList(end+1,1)=NaN; %#ok<AGROW>
        [rho,tau]=rank_correlation_from_orders(baseOrder,r.order(:)); rhoList(end+1,1)=rho; tauList(end+1,1)=tau; %#ok<AGROW>
        top1List{end+1,1}=r.finalRanking{1}; topGapList(end+1,1)=r.groupScore(r.order(1))-r.groupScore(r.order(2)); %#ok<AGROW>
    end
    for lam = cfg.sensitivity.M0.lambdaGrid
        p = p0; p.lambda = lam;
        tmp = cfg; tmp.published.cpt = p;
        r = model_M0_published(shared, tmp);
        rows{end+1,1} = 'lambda'; rankStrings{end+1,1}=strjoin(r.finalRanking(:).', ' > '); %#ok<AGROW>
        alphaList(end+1,1)=NaN; betaList(end+1,1)=NaN; lambdaList(end+1,1)=lam; gammaList(end+1,1)=NaN; deltaList(end+1,1)=NaN; %#ok<AGROW>
        [rho,tau]=rank_correlation_from_orders(baseOrder,r.order(:)); rhoList(end+1,1)=rho; tauList(end+1,1)=tau; %#ok<AGROW>
        top1List{end+1,1}=r.finalRanking{1}; topGapList(end+1,1)=r.groupScore(r.order(1))-r.groupScore(r.order(2)); %#ok<AGROW>
    end
    for gamma = cfg.sensitivity.M0.gammaGrid
        p = p0; p.gamma = gamma;
        tmp = cfg; tmp.published.cpt = p;
        r = model_M0_published(shared, tmp);
        rows{end+1,1} = 'gamma'; rankStrings{end+1,1}=strjoin(r.finalRanking(:).', ' > '); %#ok<AGROW>
        alphaList(end+1,1)=NaN; betaList(end+1,1)=NaN; lambdaList(end+1,1)=NaN; gammaList(end+1,1)=gamma; deltaList(end+1,1)=NaN; %#ok<AGROW>
        [rho,tau]=rank_correlation_from_orders(baseOrder,r.order(:)); rhoList(end+1,1)=rho; tauList(end+1,1)=tau; %#ok<AGROW>
        top1List{end+1,1}=r.finalRanking{1}; topGapList(end+1,1)=r.groupScore(r.order(1))-r.groupScore(r.order(2)); %#ok<AGROW>
    end
    for delta = cfg.sensitivity.M0.deltaGrid
        p = p0; p.delta = delta;
        tmp = cfg; tmp.published.cpt = p;
        r = model_M0_published(shared, tmp);
        rows{end+1,1} = 'delta'; rankStrings{end+1,1}=strjoin(r.finalRanking(:).', ' > '); %#ok<AGROW>
        alphaList(end+1,1)=NaN; betaList(end+1,1)=NaN; lambdaList(end+1,1)=NaN; gammaList(end+1,1)=NaN; deltaList(end+1,1)=delta; %#ok<AGROW>
        [rho,tau]=rank_correlation_from_orders(baseOrder,r.order(:)); rhoList(end+1,1)=rho; tauList(end+1,1)=tau; %#ok<AGROW>
        top1List{end+1,1}=r.finalRanking{1}; topGapList(end+1,1)=r.groupScore(r.order(1))-r.groupScore(r.order(2)); %#ok<AGROW>
    end

    T = table(string(rows), alphaList, betaList, lambdaList, gammaList, deltaList, string(rankStrings), string(top1List), topGapList, rhoList, tauList, ...
        'VariableNames', {'Sweep','alpha','beta','lambda','gamma','delta','Ranking','Top1','HeadGap','SpearmanVsM0','KendallVsM0'});
    result = struct('table', T);
end

function result = sweep_M4(shared, cfg, baseOrder, useSimilarity)
    rows = {};
    etaList = []; deltaList = []; lambda0List = [];
    rankStrings = {}; top1List = {}; topGapList = [];
    rhoList = []; tauList = [];

    for eta = cfg.sensitivity.M4.etaGrid
        tmp = cfg; tmp.newMethod.regret.eta = eta;
        r = choose_M4M5(shared, tmp, useSimilarity);
        rows{end+1,1} = 'eta'; etaList(end+1,1)=eta; deltaList(end+1,1)=NaN; lambda0List(end+1,1)=NaN; %#ok<AGROW>
        rankStrings{end+1,1}=strjoin(r.finalRanking(:).', ' > '); top1List{end+1,1}=r.finalRanking{1}; %#ok<AGROW>
        topGapList(end+1,1)=r.groupScore(r.order(1))-r.groupScore(r.order(2)); %#ok<AGROW>
        [rho,tau]=rank_correlation_from_orders(baseOrder,r.order(:)); rhoList(end+1,1)=rho; tauList(end+1,1)=tau; %#ok<AGROW>
    end
    for delta = cfg.sensitivity.M4.deltaGrid
        tmp = cfg; tmp.newMethod.regret.delta = delta;
        r = choose_M4M5(shared, tmp, useSimilarity);
        rows{end+1,1} = 'delta'; etaList(end+1,1)=NaN; deltaList(end+1,1)=delta; lambda0List(end+1,1)=NaN; %#ok<AGROW>
        rankStrings{end+1,1}=strjoin(r.finalRanking(:).', ' > '); top1List{end+1,1}=r.finalRanking{1}; %#ok<AGROW>
        topGapList(end+1,1)=r.groupScore(r.order(1))-r.groupScore(r.order(2)); %#ok<AGROW>
        [rho,tau]=rank_correlation_from_orders(baseOrder,r.order(:)); rhoList(end+1,1)=rho; tauList(end+1,1)=tau; %#ok<AGROW>
    end
    for lambda0 = cfg.sensitivity.M4.lambdaNeutralGrid
        tmp = cfg; tmp.newMethod.consensus.lambdaNeutral = lambda0*ones(shared.L,1);
        r = choose_M4M5(shared, tmp, useSimilarity);
        rows{end+1,1} = 'lambdaNeutral'; etaList(end+1,1)=NaN; deltaList(end+1,1)=NaN; lambda0List(end+1,1)=lambda0; %#ok<AGROW>
        rankStrings{end+1,1}=strjoin(r.finalRanking(:).', ' > '); top1List{end+1,1}=r.finalRanking{1}; %#ok<AGROW>
        topGapList(end+1,1)=r.groupScore(r.order(1))-r.groupScore(r.order(2)); %#ok<AGROW>
        [rho,tau]=rank_correlation_from_orders(baseOrder,r.order(:)); rhoList(end+1,1)=rho; tauList(end+1,1)=tau; %#ok<AGROW>
    end

    T = table(string(rows), etaList, deltaList, lambda0List, string(rankStrings), string(top1List), topGapList, rhoList, tauList, ...
        'VariableNames', {'Sweep','eta','delta','lambdaNeutral','Ranking','Top1','HeadGap','SpearmanVsM0','KendallVsM0'});
    result = struct('table', T);
end

function T = compact_sensitivity_table(raw)
    T = groupsummary(raw, 'Sweep', {'mean','min'}, {'HeadGap','SpearmanVsM0','KendallVsM0'});
end

function r = choose_M4M5(shared, cfg, useSimilarity)
    if useSimilarity
        r = model_M5_new_full_fj_similarity(shared, cfg);
    else
        r = model_M4_new_full_fj_neutral(shared, cfg);
    end
end

%% =============================== ROBUSTNESS ==============================

function out = run_case_robustness_suite(shared, cfg, mainResults)
    out = run_robustness_suite(shared, cfg, mainResults);
    names = fieldnames(out);
    compact = struct();
    for i = 1:numel(names)
        compact.(names{i}) = groupsummary(out.(names{i}).table, 'Perturbation', {'mean','min'}, {'MeanSpearman','MeanKendall','Top1KeepRate'});
    end
    out.compact = compact;
end

function out = run_robustness_suite(shared, cfg, mainResults)
    modelIDs = cfg.robustness.models;
    out = struct();
    baseResults = mainResults.allResults;

    for k = 1:numel(modelIDs)
        id = modelIDs{k};
        out.(id) = robustness_for_model(id, shared, cfg, baseResults.(id));
    end
end

function result = robustness_for_model(id, shared, cfg, baseResult)
    reps = cfg.robustness.repetitions;
    baseOrder = baseResult.order(:);

    blocks = {};

    for sigma = cfg.robustness.noiseSigmas
        rho = zeros(reps,1); tau = zeros(reps,1); top1 = false(reps,1);
        for r = 1:reps
            Xp = perturb_small_noise(shared.X, sigma);
            rr = run_model_on_X(id, shared, cfg, Xp);
            [rho(r), tau(r)] = rank_correlation_from_orders(baseOrder, rr.order(:));
            top1(r) = strcmp(rr.finalRanking{1}, baseResult.finalRanking{1});
        end
        blocks{end+1,1} = pack_block('noise', sigma, mean(rho), mean(tau), mean(top1)); %#ok<AGROW>
    end

    for rate = cfg.robustness.missingRates
        rho = zeros(reps,1); tau = zeros(reps,1); top1 = false(reps,1);
        for r = 1:reps
            Xp = perturb_missing_fill(shared.X, rate);
            rr = run_model_on_X(id, shared, cfg, Xp);
            [rho(r), tau(r)] = rank_correlation_from_orders(baseOrder, rr.order(:));
            top1(r) = strcmp(rr.finalRanking{1}, baseResult.finalRanking{1});
        end
        blocks{end+1,1} = pack_block('missing_fill', rate, mean(rho), mean(tau), mean(top1)); %#ok<AGROW>
    end

    for rate = cfg.robustness.extremeFlipRates
        rho = zeros(reps,1); tau = zeros(reps,1); top1 = false(reps,1);
        for r = 1:reps
            Xp = perturb_extreme_flip(shared.X, rate);
            rr = run_model_on_X(id, shared, cfg, Xp);
            [rho(r), tau(r)] = rank_correlation_from_orders(baseOrder, rr.order(:));
            top1(r) = strcmp(rr.finalRanking{1}, baseResult.finalRanking{1});
        end
        blocks{end+1,1} = pack_block('extreme_flip', rate, mean(rho), mean(tau), mean(top1)); %#ok<AGROW>
    end

    T = vertcat(blocks{:});
    result = struct();
    result.table = T;
end

function rr = run_model_on_X(id, shared, cfg, Xp)
    shared2 = shared;
    shared2.X = Xp;
    switch id
        case 'M0', rr = model_M0_published(shared2, cfg);
        case 'M4', rr = model_M4_new_full_fj_neutral(shared2, cfg);
        case 'M5', rr = model_M5_new_full_fj_similarity(shared2, cfg);
        otherwise, error('Unsupported robustness model: %s', id);
    end
end

function T = pack_block(kind, level, meanRho, meanTau, top1Rate)
    T = table(string(kind), level, meanRho, meanTau, top1Rate, ...
        'VariableNames', {'Perturbation','Level','MeanSpearman','MeanKendall','Top1KeepRate'});
end

%% ============================== CROSS-CASE ===============================

function Xn = normalize_cost_criteria(X, costCriteria)
    Xn = X;
    [L,m,n,~] = size(X);
    for j = 1:n
        if costCriteria(j)
            for l = 1:L
                for i = 1:m
                    e = get_ldf_entry_from_tensor(Xn, l, i, j);
                    Xn(l,i,j,:) = reshape(ldf_complement(e), [1,1,1,4]);
                end
            end
        end
    end
end

function Xe = get_expert_block(X, l)
    sz = size(X);
    Xe = reshape(X(l,:,:,:), [sz(2), sz(3), sz(4)]);
end

function e = get_ldf_entry(Xe, i, j)
    e = reshape(Xe(i,j,:), [1,4]);
end

function e = get_ldf_entry_from_tensor(X, l, i, j)
    e = reshape(X(l,i,j,:), [1,4]);
end

function ec = ldf_complement(e)
    ec = [e(2), e(1), e(4), e(3)];
end

function Xc = complement_ldfn_any(X)
    sz = size(X);
    Y  = reshape(X, [], 4);
    Yc = Y(:, [2 1 4 3]);
    Xc = reshape(Yc, sz);
end

function d = compute_ldf_distance(e1, e2)
    F = 2 * log2(3);
    euPart = 0.5 * sqrt(0.25 * sum((e1 - e2).^2));
    unPart = 0.5 * (abs(compute_ldf_deng_entropy(e1) - compute_ldf_deng_entropy(e2)) / F);
    d = euPart + unPart;
end

function Ed = compute_ldf_deng_entropy(e)
    e = reshape(e, [1,4]);
    A = e(1); U = e(2); a = e(3); b = e(4);
    denom = 2^2 - 1;
    Ed = local_term(a*A, denom) + local_term(b*U, denom);
end

function val = local_term(x, denom)
    if x <= 0
        val = 0;
    else
        val = -x * log2(x / denom);
    end
end

function Ed = ldfde_entropy_term(x)
    x = reshape(x, [1,4]);
    A = x(1); U = x(2); a = x(3); b = x(4);
    q = 2;
    denom = (2^q - 1);
    t1 = max(a*A, 1e-12);
    t2 = max(b*U, 1e-12);
    Ed = -t1*log2(t1/denom) - t2*log2(t2/denom);
end

function d = ndist_published(x1, x2)
    part1 = sqrt(0.25*sum((x1-x2).^2));
    F = 2*log2(2^2 - 1);
    part2 = (1/F)*abs(ldfde_entropy_term(x1) - ldfde_entropy_term(x2));
    d = 0.5*part1 + 0.5*part2;
end

function p = softmax_row(x, tau)
    x = x(:).';
    z = tau * (x - max(x));
    ez = exp(z);
    p = ez ./ sum(ez);
end

function xi = estimate_xi_cosine_heuristic(Dl, Dk)
    Dl = Dl(:); Dk = Dk(:);
    Delta = Dl - Dk;

    nDl = max(norm(Dl), 1e-12);
    nDk = max(norm(Dk), 1e-12);
    nDe = max(norm(Delta), 1e-12);

    theta_Dl = acos(clamp_scalar((nDk^2 + nDe^2 - nDl^2) / (2*nDk*nDe)));
    theta_Dk = acos(clamp_scalar((nDl^2 + nDe^2 - nDk^2) / (2*nDl*nDe)));
    theta_De = acos(clamp_scalar((nDk^2 + nDl^2 - nDe^2) / (2*nDl*nDk)));

    Xi = (theta_De/theta_Dl) - (theta_Dk/theta_Dl);
    if Xi <= -2
        xi = 0;
    elseif Xi < 2
        xi = (pi/2) * (1 + 0.5*Xi);
    else
        xi = pi;
    end
end

function y = clamp_scalar(x)
    y = min(1, max(-1, x));
end

function T = build_neutral_trust(L)
    if L < 2
        error('Neutral trust requires L >= 2.');
    end
    T = ones(L,L) - eye(L);
    T = T ./ sum(T,2);
end

function T = build_trust_matrix_from_similarity(S0, epsVal)
    [L,~] = size(S0);
    T = zeros(L,L);

    for i = 1:L
        xi = S0(i,:);
        nxi = norm(xi);
        for k = 1:L
            if i == k
                continue;
            end
            xk = S0(k,:);
            nxk = norm(xk);
            denom = max(nxi*nxk, epsVal);
            T(i,k) = max(dot(xi,xk) / denom, 0);
        end
    end

    for i = 1:L
        rowSum = sum(T(i,:));
        if rowSum <= epsVal
            T(i,:) = 1;
            T(i,i) = 0;
            rowSum = sum(T(i,:));
        end
        T(i,:) = T(i,:) / rowSum;
    end
end

function [rho, tau] = rank_correlation_from_orders(baseOrder, order2)
    baseOrder = baseOrder(:);
    order2 = order2(:);
    n = numel(baseOrder);
    r1 = zeros(n,1); r2 = zeros(n,1);
    for i = 1:n
        r1(baseOrder(i)) = i;
        r2(order2(i)) = i;
    end
    rho = corr(r1, r2, 'type', 'Spearman');
    tau = corr(r1, r2, 'type', 'Kendall');
end

function y = local_minmax(x)
    xmin = min(x);
    xmax = max(x);
    if abs(xmax - xmin) < 1e-12
        y = ones(size(x)) / numel(x);
    else
        y = (x - xmin) ./ (xmax - xmin);
    end
end

%% ============================== PERTURBATION =============================

function Xp = perturb_small_noise(X, sigma)
    Xp = X + (2*rand(size(X))-1) * sigma;
    Xp = min(max(Xp, 0), 1);
end

function Xp = perturb_missing_fill(X, missingRate)
    Xp = X;
    [L,m,n,~] = size(X);
    totalCells = L*m*n;
    k = max(1, round(missingRate * totalCells));
    idx = randperm(totalCells, k);

    for t = 1:k
        linear = idx(t);
        [l,i,j] = ind2sub([L,m,n], linear);
        pool = reshape(X(l,:,j,:), [m,4]);
        med = median(pool, 1);
        Xp(l,i,j,:) = reshape(med, [1,1,1,4]);
    end
end

function Xp = perturb_extreme_flip(X, flipRate)
    Xp = X;
    [L,m,n,~] = size(X);
    totalCells = L*m*n;
    k = max(1, round(flipRate * totalCells));
    idx = randperm(totalCells, k);

    levels = [
        0.15 0.95 0.20 0.80;
        0.27 0.85 0.30 0.70;
        0.55 0.71 0.40 0.60;
        0.64 0.62 0.50 0.50;
        0.79 0.53 0.60 0.40;
        0.88 0.41 0.70 0.30;
        0.99 0.25 0.80 0.20];

    for t = 1:k
        linear = idx(t);
        [l,i,j] = ind2sub([L,m,n], linear);
        cur = reshape(X(l,i,j,:), [1,4]);

        d = sum(abs(levels - cur), 2);
        [~, pos] = min(d);

        if pos <= 2
            newPos = min(size(levels,1), pos + 2);
        elseif pos >= size(levels,1)-1
            newPos = max(1, pos - 2);
        else
            if rand < 0.5
                newPos = pos - 2;
            else
                newPos = pos + 2;
            end
        end
        Xp(l,i,j,:) = reshape(levels(newPos,:), [1,1,1,4]);
    end
end
