function out = run_revision_package(cfg)
%RUN_REVISION_PACKAGE Reviewer-facing reproducibility package.
% Runs the cleaned CASE1/CASE3 redesign pipeline and exports the data,
% intermediate matrices, sensitivity checks, and robustness summaries needed
% for the revised manuscript and supplementary material.

    if nargin < 1 || isempty(cfg)
        cfg = struct();
    end

    thisDir = fileparts(mfilename('fullpath'));
    addpath(thisDir);

    defaults = local_default_revision_config();
    cfg = merge_structs(defaults, cfg);
    if ~exist(cfg.outputDir, 'dir')
        mkdir(cfg.outputDir);
    end

    redesignCfg = rmfield(cfg, 'runBothCases');
    redesignCfg.saveOutputs = true;
    redesignCfg.outputDir = cfg.outputDir;

    out = struct();
    if cfg.runBothCases
        out.case1 = run_case1_redesign_ablation_baselines(redesignCfg);
        export_revision_tables(out.case1, cfg.outputDir);

        out.case3 = run_case3_redesign_ablation_baselines(redesignCfg);
        export_revision_tables(out.case3, cfg.outputDir);
    else
        out.case1 = [];
        out.case3 = [];
    end

    metadata = struct();
    metadata.packageName = 'M3R reviewer-facing revision package';
    metadata.generatedBy = mfilename;
    metadata.randomSeed = cfg.randomSeed;
    metadata.robust = cfg.robust;
    metadata.consensus = cfg.consensus;
    metadata.robustness = cfg.robustness;
    metadata.parameterSensitivity = cfg.parameterSensitivity;
    metadata.specificationSensitivity = cfg.specificationSensitivity;
    write_json_metadata(fullfile(cfg.outputDir, 'run_metadata.json'), metadata);
end

function cfg = local_default_revision_config()
    cfg = struct();
    cfg.randomSeed = 20260409;
    cfg.outputDir = fullfile(pwd, 'revision_outputs');
    cfg.runBothCases = true;

    cfg.saveOutputs = true;

    cfg.robust = struct();
    cfg.robust.mode = 'winsor';
    cfg.robust.winsorPct = 0.05;
    cfg.robust.quantileMethod = 'linear';
    cfg.robust.renormalize = true;
    cfg.robust.huberC = 1.5;
    cfg.robust.eps = 1e-12;

    cfg.consensus = struct();
    cfg.consensus.lambdaNeutral = [];
    cfg.consensus.maxIter = 500;
    cfg.consensus.tol = 1e-10;
    cfg.consensus.similarityEps = 1e-12;
    cfg.consensus.alphaShrink = 0.50;
    cfg.consensus.alphaGrid = (0:0.1:1).';
    cfg.consensus.lambdaGrid = [0.30 0.50 0.70].';

    cfg.robustness = struct();
    cfg.robustness.enabled = true;
    cfg.robustness.models = {'M0','A0','A1','A2','A3','B1','B2','B3'};
    cfg.robustness.repetitions = 100;
    cfg.robustness.weightLevels = [0.05 0.10 0.15];
    cfg.robustness.noiseLevels = [0.01 0.03 0.05];
    cfg.robustness.extremeLevels = [0.02 0.05 0.10];
    cfg.robustness.missingLevels = [0.05 0.10 0.15];

    cfg.parameterSensitivity = struct();
    cfg.parameterSensitivity.tauGrid = [0 0.01 0.03 0.05 0.10].';
    cfg.parameterSensitivity.lambdaGrid = [0.30 0.50 0.70].';

    cfg.specificationSensitivity = struct();
    cfg.specificationSensitivity.quantileMethods = {'linear','nearest','lower','higher'};
    cfg.specificationSensitivity.uniformShrinkWeight = 0.05;
end

function export_revision_tables(result, outputDir)
    prefix = lower(result.caseID);
    shared = result.shared;

    writetable(ldf_tensor_to_long_table(shared.X, shared, 'input_tensor'), ...
        fullfile(outputDir, [prefix '_input_tensor.csv']));

    if isfield(shared, 'rawIVFF') && ~isempty(shared.rawIVFF)
        writetable(ivff_tensor_to_long_table(shared), ...
            fullfile(outputDir, [prefix '_raw_ivff_terms.csv']));
        writetable(ldf_tensor_to_long_table(shared.X, shared, 'converted_tensor'), ...
            fullfile(outputDir, [prefix '_converted_tensor.csv']));
    end

    writetable(matrix_to_long_table(result.caseID, 'W', result.signal.weights, shared.experts, shared.criteria), ...
        fullfile(outputDir, [prefix '_W.csv']));
    writetable(matrix_to_long_table(result.caseID, 'AC', result.signal.AC, shared.experts, shared.alternatives), ...
        fullfile(outputDir, [prefix '_AC.csv']));
    writetable(matrix_to_long_table(result.caseID, 'Pcond', result.signal.Pcond, shared.experts, shared.alternatives), ...
        fullfile(outputDir, [prefix '_Pcond.csv']));
    writetable(matrix_to_long_table(result.caseID, 'S0rob', result.signal.PcondWinsor, shared.experts, shared.alternatives), ...
        fullfile(outputDir, [prefix '_S0rob.csv']));
    writetable(matrix_to_long_table(result.caseID, 'T', result.models.A3.backend.T, shared.experts, shared.experts), ...
        fullfile(outputDir, [prefix '_T.csv']));
    writetable(matrix_to_long_table(result.caseID, 'Zeq', result.models.A3.backend.fj.Zeq, shared.experts, shared.alternatives), ...
        fullfile(outputDir, [prefix '_Zeq.csv']));
    writetable(vector_to_table(result.caseID, 'G', result.models.A3.groupScore, shared.alternatives), ...
        fullfile(outputDir, [prefix '_G.csv']));

    writetable(result.mainSummary, fullfile(outputDir, [prefix '_main_summary.csv']));
    writetable(result.trustDiagnostics, fullfile(outputDir, [prefix '_trust_diagnostics.csv']));
    writetable(result.alphaSensitivity.table, fullfile(outputDir, [prefix '_alpha_sensitivity.csv']));
    writetable(result.parameterSensitivity.tau, fullfile(outputDir, [prefix '_tau_sensitivity.csv']));
    writetable(result.parameterSensitivity.lambda, fullfile(outputDir, [prefix '_lambda_sensitivity.csv']));
    writetable(result.specificationSensitivity.table, fullfile(outputDir, [prefix '_specification_sensitivity.csv']));
    writetable(result.winsorAudit, fullfile(outputDir, [prefix '_winsor_audit.csv']));

    if isfield(result, 'bridgeSensitivity') && ~isempty(result.bridgeSensitivity)
        writetable(result.bridgeSensitivity, fullfile(outputDir, [prefix '_bridge_sensitivity.csv']));
    end

    if isfield(result, 'robustness') && isfield(result.robustness, 'trialTable') && ~isempty(result.robustness.trialTable)
        writetable(result.robustness.trialTable, fullfile(outputDir, [prefix '_robustness_trials.csv']));
        writetable(result.robustness.summary, fullfile(outputDir, [prefix '_robustness_summary.csv']));
        writetable(result.robustness.pairedVsM0, fullfile(outputDir, [prefix '_paired_vs_M0.csv']));
        writetable(result.robustness.rankingSummary, fullfile(outputDir, [prefix '_ranking_stability_summary.csv']));
    end
end

function T = ldf_tensor_to_long_table(X, shared, matrixName)
    CaseID = strings(0,1);
    Matrix = strings(0,1);
    Expert = strings(0,1);
    Alternative = strings(0,1);
    Criterion = strings(0,1);
    A = zeros(0,1);
    U = zeros(0,1);
    a = zeros(0,1);
    b = zeros(0,1);

    for l = 1:shared.L
        for i = 1:shared.m
            for j = 1:shared.n
                e = reshape(X(l,i,j,:), [1,4]);
                CaseID(end+1,1) = string(shared.caseID); %#ok<AGROW>
                Matrix(end+1,1) = string(matrixName); %#ok<AGROW>
                Expert(end+1,1) = string(shared.experts{l}); %#ok<AGROW>
                Alternative(end+1,1) = string(shared.alternatives{i}); %#ok<AGROW>
                Criterion(end+1,1) = string(shared.criteria{j}); %#ok<AGROW>
                A(end+1,1) = e(1); %#ok<AGROW>
                U(end+1,1) = e(2); %#ok<AGROW>
                a(end+1,1) = e(3); %#ok<AGROW>
                b(end+1,1) = e(4); %#ok<AGROW>
            end
        end
    end
    T = table(CaseID, Matrix, Expert, Alternative, Criterion, A, U, a, b);
end

function T = ivff_tensor_to_long_table(shared)
    CaseID = strings(0,1);
    Expert = strings(0,1);
    Alternative = strings(0,1);
    Criterion = strings(0,1);
    Term = strings(0,1);
    ZetaLow = zeros(0,1);
    ZetaHigh = zeros(0,1);
    EtaLow = zeros(0,1);
    EtaHigh = zeros(0,1);

    for l = 1:shared.L
        for i = 1:shared.m
            for j = 1:shared.n
                e = reshape(shared.rawIVFF(l,i,j,:), [1,4]);
                CaseID(end+1,1) = string(shared.caseID); %#ok<AGROW>
                Expert(end+1,1) = string(shared.experts{l}); %#ok<AGROW>
                Alternative(end+1,1) = string(shared.alternatives{i}); %#ok<AGROW>
                Criterion(end+1,1) = string(shared.criteria{j}); %#ok<AGROW>
                Term(end+1,1) = string(shared.termLabels{l,i,j}); %#ok<AGROW>
                ZetaLow(end+1,1) = e(1); %#ok<AGROW>
                ZetaHigh(end+1,1) = e(2); %#ok<AGROW>
                EtaLow(end+1,1) = e(3); %#ok<AGROW>
                EtaHigh(end+1,1) = e(4); %#ok<AGROW>
            end
        end
    end
    T = table(CaseID, Expert, Alternative, Criterion, Term, ZetaLow, ZetaHigh, EtaLow, EtaHigh);
end

function T = matrix_to_long_table(caseID, matrixName, M, rowLabels, colLabels)
    CaseID = strings(0,1);
    Matrix = strings(0,1);
    RowLabel = strings(0,1);
    ColumnLabel = strings(0,1);
    Value = zeros(0,1);
    for i = 1:size(M,1)
        for j = 1:size(M,2)
            CaseID(end+1,1) = string(caseID); %#ok<AGROW>
            Matrix(end+1,1) = string(matrixName); %#ok<AGROW>
            RowLabel(end+1,1) = string(rowLabels{i}); %#ok<AGROW>
            ColumnLabel(end+1,1) = string(colLabels{j}); %#ok<AGROW>
            Value(end+1,1) = M(i,j); %#ok<AGROW>
        end
    end
    T = table(CaseID, Matrix, RowLabel, ColumnLabel, Value);
end

function T = vector_to_table(caseID, vectorName, v, labels)
    CaseID = strings(numel(v),1);
    Vector = strings(numel(v),1);
    Label = strings(numel(v),1);
    Value = zeros(numel(v),1);
    for i = 1:numel(v)
        CaseID(i) = string(caseID);
        Vector(i) = string(vectorName);
        Label(i) = string(labels{i});
        Value(i) = v(i);
    end
    T = table(CaseID, Vector, Label, Value);
end

function write_json_metadata(path, metadata)
    fid = fopen(path, 'w');
    if fid < 0
        error('Cannot write metadata file: %s', path);
    end
    cleaner = onCleanup(@() fclose(fid));
    fprintf(fid, '%s', jsonencode(metadata));
    clear cleaner;
end

function out = merge_structs(base, override)
    out = base;
    if isempty(override)
        return;
    end
    f = fieldnames(override);
    for i = 1:numel(f)
        key = f{i};
        if isstruct(override.(key)) && isfield(out, key) && isstruct(out.(key))
            out.(key) = merge_structs(out.(key), override.(key));
        else
            out.(key) = override.(key);
        end
    end
end
