function result = run_case1_redesign_ablation_baselines(cfg)
%RUN_CASE1_REDESIGN_ABLATION_BASELINES Wrapper for CASE1.
% Ensures the current file folder is on path, loads CASE1 shared input in a
% light mode, and then calls the redesigned reviewer-facing framework.

    if nargin < 1
        cfg = [];
    end

    thisDir = fileparts(mfilename('fullpath'));
    addpath(thisDir);

    if exist('run_case1_only', 'file') ~= 2
        error('Cannot find run_case1_only.m on MATLAB path.');
    end
    if exist('run_case_ablation_baseline_redesign', 'file') ~= 2
        error('Cannot find run_case_ablation_baseline_redesign.m on MATLAB path.');
    end

    loadCfg = local_light_case_cfg();
    evalc('tmpCase = run_case1_only(loadCfg);');
    result = run_case_ablation_baseline_redesign(tmpCase.shared, cfg);
end

function cfg = local_light_case_cfg()
    cfg = struct();
    cfg.randomSeed = 20260331;
    cfg.saveOutputs = false;
    cfg.outputDir = '';
    cfg.main.modelIDs = {'M0'};
    cfg.published.cpt.alpha  = 0.88;
    cfg.published.cpt.beta   = 0.88;
    cfg.published.cpt.lambda = 2.25;
    cfg.published.cpt.gamma  = 0.61;
    cfg.published.cpt.delta  = 0.69;
    cfg.published.cpt.useAltWeighting = false;
    cfg.published.groupWeights = [1/3; 1/3; 1/3];
    cfg.newMethod.consensus.groupWeights = [1/3; 1/3; 1/3];
    cfg.newMethod.consensus.lambdaNeutral = [0.5; 0.5; 0.5];
    cfg.sensitivity.enabled = false;
    cfg.robustness.enabled = false;
end
